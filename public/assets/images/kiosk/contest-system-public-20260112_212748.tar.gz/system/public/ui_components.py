"""
UI Components for Competition Programming Interface
Модулі інтерфейсу для змагань з програмування
"""

import ipywidgets as widgets
import os
import json
import markdown

def get_card_style():
    """Стиль для карток"""
    return "background:white;border-radius:12px;box-shadow:0 4px 6px -1px rgba(0,0,0,0.1);border:1px solid #e5e7eb;padding:24px;margin:16px 0;"

def get_code_style():
    """Стиль для блоків коду"""
    return "background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:16px;font-family:monospace;font-size:14px;overflow-x:auto;color:#1f2937;"

def get_verdict_translation(verdict):
    """Повертає український переклад вердикту"""
    verdict_names = {
        'AC': 'Зараховано',
        'WA': 'Неправильна відповідь',
        'TLE': 'Перевищено час',
        'RE': 'Помилка виконання',
        'CE': 'Помилка компіляції',
        'ERROR': 'Системна помилка'
    }
    return verdict_names.get(verdict, verdict)

def get_header_html(contest_name, problem_count, language_count):
    """Генерує HTML заголовка"""
    return f'''
    <div style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);border-radius:16px;padding:32px;text-align:center;color:white;box-shadow:0 10px 25px -5px rgba(0,0,0,0.1);">
        <h1 style="margin:0;font-size:36px;font-weight:800;text-shadow:0 2px 4px rgba(0,0,0,0.3);">🏆 {contest_name}</h1>
        <div style="margin-top:12px;font-size:16px;font-weight:500;opacity:0.9">{problem_count} задач • {language_count} мов</div>
    </div>'''

def get_section_header(title, color="#3b82f6", background_color="#f8f9fa"):
    """Генерує HTML заголовка розділу"""
    return f'''
    <div style="margin: 24px 0 16px 0; background: {background_color}; border-radius: 8px; padding: 16px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);">
        <h2 style="color:#1f2937;font-size:24px;font-weight:700;margin:0;display:flex;align-items:center;">
            <span style="background:{color};width:6px;height:24px;border-radius:3px;margin-right:12px;"></span>
            {title}
        </h2>
    </div>'''

def load_examples_from_tests(problem_id, contest_path='contest'):
    """Завантажує приклади з тестових файлів блоку 0"""
    examples = []

    try:
        # Шлях до тестів
        tests_dir = f'{contest_path}/{problem_id}/tests/tests'

        # Знаходимо всі файли блоку 0 (приклади)
        test_files = []
        for file in os.listdir(tests_dir):
            if file.startswith('0-') and file.endswith('.in'):
                test_id = file.split('-')[1].split('.')[0]
                test_files.append(int(test_id))

        # Сортуємо тести за номером
        test_files.sort()

        # Читаємо кожен тест
        for test_id in test_files:
            input_file = f'0-{test_id}.in'
            output_file = f'0-{test_id}.out'

            input_path = os.path.join(tests_dir, input_file)
            output_path = os.path.join(tests_dir, output_file)

            if os.path.exists(input_path) and os.path.exists(output_path):
                # Читаємо вміст файлів
                with open(input_path, 'r', encoding='utf-8') as f:
                    input_content = f.read().rstrip()

                with open(output_path, 'r', encoding='utf-8') as f:
                    output_content = f.read().rstrip()

                examples.append({
                    'input': input_content,
                    'output': output_content
                })

    except Exception as e:
        print(f"Помилка завантаження прикладів для задачі {problem_id}: {e}")

    return examples

def get_problem_html(problem_data, test_count):
    """Генерує HTML для відображення задачі"""
    card_style = get_card_style()
    code_style = get_code_style()

    # Завантажуємо приклади з тестових файлів
    examples = load_examples_from_tests(problem_data.get('id', ''))

    examples_html = ""
    for i, example in enumerate(examples, 1):
        examples_html += f'''
        <div style="margin: 16px 0;">
            <div style="font-weight: 600; color: #374151; margin-bottom: 8px;">Приклад {i}:</div>
            <div style="margin-bottom: 12px;">
                <div style="font-weight: 500; color: #6b7280; margin-bottom: 4px;">Вхід:</div>
                <pre style="{code_style}">{example['input']}</pre>
            </div>
            <div>
                <div style="font-weight: 500; color: #6b7280; margin-bottom: 4px;">Вихід:</div>
                <pre style="{code_style}">{example['output']}</pre>
            </div>
        </div>'''

    return f'''
    <div style="{card_style}">
        <div style="border-bottom: 2px solid #e5e7eb; padding-bottom: 16px; margin-bottom: 24px;">
            <h1 style="color: #1f2937; font-size: 28px; font-weight: 700; margin: 0; display: flex; align-items: center;">
                <span style="background: #3b82f6; color: white; width: 40px; height: 40px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; font-size: 18px; margin-right: 12px;">{problem_data.get('id', '')}</span>
                {problem_data['title']}
            </h1>
        </div>

        <div style="margin-bottom: 24px;">
            <h3 style="color: #374151; font-size: 18px; font-weight: 600; margin: 0 0 12px 0;">Умова задачі</h3>
            <div style="color: #4b5563; line-height: 1.7; font-size: 15px;">
                {process_markdown(problem_data['legend'])}
            </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px;">
            <div>
                <h3 style="color: #374151; font-size: 16px; font-weight: 600; margin: 0 0 8px 0;">Вхідні дані</h3>
                <div style="color: #6b7280; line-height: 1.6; font-size: 14px;">
                    {process_markdown(problem_data['input'])}
                </div>
            </div>
            <div>
                <h3 style="color: #374151; font-size: 16px; font-weight: 600; margin: 0 0 8px 0;">Вихідні дані</h3>
                <div style="color: #6b7280; line-height: 1.6; font-size: 14px;">
                    {process_markdown(problem_data['output'])}
                </div>
            </div>
        </div>

        <div style="margin-bottom: 24px;">
            <h3 style="color: #374151; font-size: 18px; font-weight: 600; margin: 0 0 16px 0;">Приклади</h3>
            {examples_html}
        </div>

        <div style="background: #f0f9ff; border: 1px solid #0ea5e9; border-radius: 8px; padding: 12px;">
            <div style="color: #0c4a6e; font-weight: 500;">
                📊 Тестових випадків: {test_count}
            </div>
        </div>
    </div>'''

def get_verdict_style(verdict):
    """Повертає стилі для різних вердиктів"""
    styles = {
        'AC': {'bg': '#dcfce7', 'border': '#16a34a', 'text': '#15803d'},
        'WA': {'bg': '#fef2f2', 'border': '#dc2626', 'text': '#dc2626'},
        'TLE': {'bg': '#fef3c7', 'border': '#d97706', 'text': '#d97706'},
        'RE': {'bg': '#f3e8ff', 'border': '#9333ea', 'text': '#9333ea'},
        'CE': {'bg': '#f1f5f9', 'border': '#64748b', 'text': '#64748b'},
        'ERROR': {'bg': '#fef2f2', 'border': '#dc2626', 'text': '#dc2626'}
    }
    return styles.get(verdict, styles['ERROR'])

def get_block_results_html(result_data):
    """Генерує HTML для відображення результатів з блоками"""
    card_style = get_card_style()
    verdict = result_data['verdict']
    total_score = result_data.get('total_score', 0)
    max_total_score = result_data.get('max_total_score', 0)
    passed_tests = result_data['passed_tests']
    total_tests = result_data['total_tests']
    total_time = result_data['total_time']
    compile_error = result_data.get('compile_error')
    blocks = result_data.get('blocks', [])

    verdict_emojis = {
        'AC': '✅', 'WA': '❌', 'TLE': '⏰', 'RE': '💥', 'CE': '🔨', 'ERROR': '⚠️'
    }

    style = get_verdict_style(verdict)
    emoji = verdict_emojis.get(verdict, '❓')
    name = get_verdict_translation(verdict)

    # Головний заголовок
    html = f'''
    <div style="{card_style}">
        <div style="display: flex; align-items: center; margin-bottom: 24px;">
            <div style="font-size: 48px; margin-right: 16px;">{emoji}</div>
            <div>
                <h1 style="color: {style['text']}; font-size: 32px; font-weight: 700; margin: 0; line-height: 1;">
                    {name}
                </h1>
                <div style="color: #6b7280; font-size: 16px; margin-top: 4px;">
                    {passed_tests}/{total_tests} тестів пройдено • {total_score}/{max_total_score} балів • {total_time:.3f}с
                </div>
            </div>
        </div>
    '''

    # Якщо є помилка компіляції
    if compile_error:
        html += f'''
        <div style="background: #fef2f2; border: 1px solid #dc2626; border-radius: 8px; padding: 16px; margin-bottom: 16px;">
            <div style="color: #dc2626; font-weight: 600; margin-bottom: 8px;">🔨 Помилка компіляції</div>
            <div style="color: #374151; font-family: monospace; font-size: 14px; white-space: pre-wrap; background: white; padding: 12px; border-radius: 4px;">
{compile_error}
            </div>
        </div>
        '''

    # Відображення блоків
    if blocks:
        for block in blocks:
            block_id = block['block_id']
            block_name = block['name']
            block_score = block['score']
            block_max_score = block['max_score']
            block_verdict = block['verdict']
            block_passed = block['passed_tests']
            block_total = block['total_tests']
            test_results = block.get('test_results', [])

            block_style = get_verdict_style(block_verdict)
            block_emoji = verdict_emojis.get(block_verdict, '❓')

            html += f'''
        <div style="background: {block_style['bg']}; border: 1px solid {block_style['border']}; border-radius: 8px; padding: 16px; margin-bottom: 12px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                <div style="color: {block_style['text']}; font-weight: 600; font-size: 16px;">
                    {block_emoji} {block_name}
                </div>
                <div style="color: {block_style['text']}; font-size: 14px; font-weight: 500;">
                    {block_score}/{block_max_score} балів ({block_passed}/{block_total} тестів)
                </div>
            </div>
            '''

            # Деталі тестів у блоці
            if test_results:
                html += '<div style="margin-top: 8px;">'
                for test in test_results:
                    test_id = test['test_id']
                    test_verdict = test['verdict']
                    test_score = test.get('earned_score', 0)
                    test_max_score = test.get('score', 0)
                    test_time = test['time']

                    test_emoji = verdict_emojis.get(test_verdict, '❓')

                    if test_verdict == 'AC':
                        test_color = '#16a34a'
                        test_bg = '#f0fdf4'
                    else:
                        test_color = '#dc2626'
                        test_bg = '#fef2f2'

                    html += f'''
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 6px 12px; margin: 2px 0; background: {test_bg}; border-radius: 4px; border-left: 3px solid {test_color};">
                        <div style="color: {test_color}; font-size: 14px;">
                            {test_emoji} Тест {test_id}: {get_verdict_translation(test_verdict)}
                        </div>
                        <div style="color: {test_color}; font-size: 14px; font-weight: 500;">
                            {test_score}/{test_max_score} балів • {test_time:.3f}с
                        </div>
                    </div>
                    '''
                html += '</div>'

            html += '</div>'

    html += '</div>'
    return html

def get_results_html(result_data):
    """Генерує HTML для відображення результатів"""
    card_style = get_card_style()
    verdict = result_data['verdict']
    passed_tests = result_data['passed_tests']
    total_tests = result_data['total_tests']
    total_time = result_data['total_time']
    compile_error = result_data.get('compile_error')
    test_results = result_data.get('test_results', [])

    verdict_emojis = {
        'AC': '✅', 'WA': '❌', 'TLE': '⏰', 'RE': '💥', 'CE': '🔨', 'ERROR': '⚠️'
    }

    style = get_verdict_style(verdict)
    emoji = verdict_emojis.get(verdict, '❓')
    name = get_verdict_translation(verdict)

    html = f'''
    <div style="{card_style}">
        <div style="display: flex; align-items: center; margin-bottom: 24px;">
            <div style="font-size: 48px; margin-right: 16px;">{emoji}</div>
            <div>
                <h1 style="color: {style['text']}; font-size: 32px; font-weight: 700; margin: 0; line-height: 1;">
                    {name}
                </h1>
                <div style="color: #6b7280; font-size: 16px; margin-top: 4px;">
                    {passed_tests}/{total_tests} тестів пройдено • {total_time:.3f}с
                </div>
            </div>
        </div>

        <div style="background: {style['bg']}; border: 1px solid {style['border']}; border-radius: 8px; padding: 16px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="color: {style['text']}; font-weight: 600;">Підсумки результатів тестів</div>
                <div style="color: {style['text']}; font-size: 14px;">
                    Відсоток успіху: {(passed_tests/total_tests*100):.1f}%
                </div>
            </div>
        </div>
    </div>'''

    # Обробка помилок компіляції
    if verdict == 'CE' or compile_error:
        html += f'''
        <div style="{card_style}">
            <h3 style="color: #374151; font-size: 18px; font-weight: 600; margin: 0 0 16px 0;">Помилка компіляції</h3>
            <div style="background: #fef2f2; border: 1px solid #fca5a5; border-radius: 8px; padding: 16px;">
                <pre style="color: #dc2626; font-family: monospace; font-size: 14px; white-space: pre-wrap; margin: 0; line-height: 1.5;">{compile_error}</pre>
            </div>
        </div>'''

    # Індивідуальні результати тестів
    elif test_results and verdict != 'ERROR':
        test_grid_html = ""
        code_style = get_code_style()

        for test in test_results:
            test_verdict = test['verdict']
            test_style = get_verdict_style(test_verdict)
            test_emoji = verdict_emojis.get(test_verdict, '❓')

            details_html = ""
            if test_verdict in ['WA', 'TLE', 'RE']:
                if test_verdict == 'WA':
                    details_html = f'''
                    <div style="margin-top: 12px; display: none;" class="test-details">
                        <div style="margin-bottom: 8px;">
                            <div style="font-weight: 500; color: #374151; margin-bottom: 4px;">Вхід:</div>
                            <pre style="{code_style} max-height: 120px; overflow-y: auto;">{test['input'][:300]}{'...' if len(test['input']) > 300 else ''}</pre>
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                            <div>
                                <div style="font-weight: 500; color: #374151; margin-bottom: 4px;">Очікувано:</div>
                                <pre style="{code_style} max-height: 120px; overflow-y: auto;">{test['expected'][:300]}{'...' if len(test['expected']) > 300 else ''}</pre>
                            </div>
                            <div>
                                <div style="font-weight: 500; color: #374151; margin-bottom: 4px;">Ваш вихід:</div>
                                <pre style="{code_style} max-height: 120px; overflow-y: auto;">{test['actual'][:300]}{'...' if len(test['actual']) > 300 else ''}</pre>
                            </div>
                        </div>
                    </div>'''
                else:
                    error_msg = "Перевищення часу" if test_verdict == 'TLE' else "Виникла помилка виконання"
                    details_html = f'''
                    <div style="margin-top: 12px; display: none;" class="test-details">
                        <div style="color: {test_style['text']}; font-weight: 500;">{error_msg}</div>
                        <div style="margin-top: 8px;">
                            <div style="font-weight: 500; color: #374151; margin-bottom: 4px;">Вхід:</div>
                            <pre style="{code_style} max-height: 120px; overflow-y: auto;">{test['input'][:300]}{'...' if len(test['input']) > 300 else ''}</pre>
                        </div>
                    </div>'''

            test_grid_html += f'''
            <div style="border: 1px solid {test_style['border']}; border-radius: 8px; padding: 16px; background: {test_style['bg']}; cursor: pointer;"
                 onclick="var details = this.querySelector('.test-details'); details.style.display = details.style.display === 'none' ? 'block' : 'none';">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div style="display: flex; align-items: center;">
                        <span style="font-size: 20px; margin-right: 8px;">{test_emoji}</span>
                        <span style="font-weight: 600; color: {test_style['text']};">Тест {test['test']}</span>
                    </div>
                    <div style="text-align: right;">
                        <div style="color: {test_style['text']}; font-weight: 500;">{get_verdict_translation(test_verdict)}</div>
                        <div style="color: #6b7280; font-size: 12px;">{test['time']:.3f}с</div>
                    </div>
                </div>
                {details_html}
            </div>'''

        html += f'''
        <div style="{card_style}">
            <h3 style="color: #374151; font-size: 18px; font-weight: 600; margin: 0 0 16px 0;">Деталі тестових випадків</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 12px;">
                {test_grid_html}
            </div>
            <div style="margin-top: 16px; padding: 12px; background: #f8fafc; border-radius: 8px; color: #64748b; font-size: 14px; text-align: center;">
                💡 Клікніть на невдалі тести, щоб побачити деталі
            </div>
        </div>'''

    return html

def get_loading_html(message="Тестування..."):
    """HTML для відображення завантаження"""
    return f'<div style="{get_card_style()}"><div style="color: #3b82f6; font-weight: 500; display: flex; align-items: center;"><div style="width: 20px; height: 20px; border: 2px solid #3b82f6; border-top-color: transparent; border-radius: 50%; margin-right: 12px; animation: spin 1s linear infinite;"></div>🔄 {message}</div></div>'

def get_pending_submission_html():
    """HTML для відображення очікування подачі"""
    return f'''<div style="{get_card_style()}">
        <div style="color: #f59e0b; font-weight: 600; display: flex; align-items: center; font-size: 16px;">
            <div style="width: 20px; height: 20px; border: 2px solid #f59e0b; border-top-color: transparent; border-radius: 50%; margin-right: 12px; animation: spin 1s linear infinite;"></div>
            📤 Подача в обробці...
        </div>
        <div style="color: #92400e; margin-top: 8px; font-size: 14px; font-weight: 500;">
            Ваше рішення тестується на всіх тест-кейсах. Будь ласка, зачекайте.
        </div>
        <style>
            @keyframes spin {{
                0% {{ transform: rotate(0deg); }}
                100% {{ transform: rotate(360deg); }}
            }}
        </style>
    </div>'''

def get_error_html(message):
    """HTML для відображення помилок"""
    return f'<div style="{get_card_style()}"><div style="color: #dc2626; font-weight: 500;">⚠️ {message}</div></div>'

def get_submission_section_header(title, color="#10b981"):
    """Генерує HTML заголовка для секцій подачі в стилі карток"""
    return f'''
    <div style="{get_card_style()}">
        <h3 style="color:#1f2937;font-size:20px;font-weight:600;margin:0 0 16px 0;display:flex;align-items:center;">
            <span style="background:{color};width:4px;height:20px;border-radius:2px;margin-right:10px;"></span>
            {title}
        </h3>
    '''

def get_submission_section_footer():
    """Закриває секцію подачі"""
    return "</div>"

def get_final_submission_header():
    """HTML заголовок для фінальної подачі в стилі карток"""
    return f'''
    <div style="{get_card_style()}">
        <div style="text-align: center; margin-bottom: 20px;">
            <h2 style="color: #1f2937; font-size: 28px; font-weight: 700; margin: 0 0 8px 0; display: flex; align-items: center; justify-content: center;">
                <span style="background: #8b5cf6; color: white; width: 40px; height: 40px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; font-size: 18px; margin-right: 12px;">🎯</span>
                Фінальна подача
            </h2>
            <p style="color: #6b7280; margin: 0; font-size: 16px; line-height: 1.5;">
                Завантажте остаточні рішення для всіх задач. Система протестує їх та створить ZIP архів для подачі результатів змагання.
            </p>
        </div>
    </div>
    '''

def get_problem_html_no_card(problem_data, test_count):
    """Генерує HTML для відображення задачі без картки (для використання всередині загальної картки)"""
    code_style = get_code_style()

    # Завантажуємо приклади з тестових файлів
    examples = load_examples_from_tests(problem_data.get('id', ''))

    examples_html = ""
    for i, example in enumerate(examples, 1):
        examples_html += f'''
        <div style="margin: 16px 0;">
            <div style="font-weight: 600; color: #374151; margin-bottom: 8px;">Приклад {i}:</div>
            <div style="margin-bottom: 12px;">
                <div style="font-weight: 500; color: #6b7280; margin-bottom: 4px;">Вхід:</div>
                <pre style="{code_style}">{example['input']}</pre>
            </div>
            <div>
                <div style="font-weight: 500; color: #6b7280; margin-bottom: 4px;">Вихід:</div>
                <pre style="{code_style}">{example['output']}</pre>
            </div>
        </div>'''

    return f'''
        <div style="border-bottom: 2px solid #e5e7eb; padding-bottom: 16px; margin-bottom: 24px;">
            <h1 style="color: #1f2937; font-size: 28px; font-weight: 700; margin: 0; display: flex; align-items: center;">
                <span style="background: #3b82f6; color: white; width: 40px; height: 40px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; font-size: 18px; margin-right: 12px;">{problem_data.get('id', '')}</span>
                {problem_data['title']}
            </h1>
        </div>

        <div style="margin-bottom: 24px;">
            <h3 style="color: #374151; font-size: 18px; font-weight: 600; margin: 0 0 12px 0;">Умова задачі</h3>
            <div style="color: #4b5563; line-height: 1.7; font-size: 15px;">
                {process_markdown(problem_data['legend'])}
            </div>
        </div>

        <div style="margin-bottom: 24px;">
            <h3 style="color: #374151; font-size: 18px; font-weight: 600; margin: 0 0 12px 0;">Формат вводу</h3>
            <div style="color: #4b5563; line-height: 1.7; font-size: 15px;">
                {process_markdown(problem_data['input_format'])}
            </div>
        </div>

        <div style="margin-bottom: 24px;">
            <h3 style="color: #374151; font-size: 18px; font-weight: 600; margin: 0 0 12px 0;">Формат виводу</h3>
            <div style="color: #4b5563; line-height: 1.7; font-size: 15px;">
                {process_markdown(problem_data['output_format'])}
            </div>
        </div>

        {f'<div style="margin-bottom: 24px;"><h3 style="color: #374151; font-size: 18px; font-weight: 600; margin: 0 0 12px 0;">Приклади</h3>{examples_html}</div>' if examples_html else ''}

        <div style="display: flex; flex-wrap: wrap; gap: 16px; font-size: 14px; color: #6b7280;">
            <div><strong>Тестів:</strong> {test_count}</div>
            <div><strong>Часовий ліміт:</strong> {problem_data.get('time_limit', 'Не вказано')}</div>
            <div><strong>Ліміт пам'яті:</strong> {problem_data.get('memory_limit', 'Не вказано')}</div>
        </div>
    '''

def get_error_html_no_card(message):
    """HTML для відображення помилок без картки"""
    return f'<div style="color: #dc2626; font-weight: 500;">⚠️ {message}</div>'

def process_markdown(text):
    """Обробляє Markdown текст в HTML"""
    if not text:
        return ""

    # Налаштування markdown з розширеннями
    md = markdown.Markdown(extensions=[
        'extra',      # Додаткові функції (таблиці, сноски тощо)
        'codehilite', # Підсвічування коду
        'toc'         # Генерація змісту
    ])

    return md.convert(text)


def get_scoring_section(problem_data):
    """Генерує HTML секцію для системи оцінювання"""
    scoring = problem_data.get('scoring')
    if not scoring:
        return ""

    return f'''
    <div style="margin-bottom: 24px;">
        <h3 style="color: #374151; font-size: 18px; font-weight: 600; margin: 0 0 12px 0; display: flex; align-items: center;">
            <span style="background: #8b5cf6; width: 3px; height: 18px; border-radius: 2px; margin-right: 8px;"></span>
            Система оцінювання
        </h3>
        <div style="background: #faf5ff; border: 1px solid #8b5cf6; border-radius: 8px; padding: 16px;">
            <div style="color: #6b21a8; line-height: 1.7; font-size: 15px;">
                {process_markdown(scoring)}
            </div>
        </div>
    </div>
    '''


def get_notes_section(problem_data):
    """Генерує HTML секцію для приміток"""
    notes = problem_data.get('notes')
    if not notes:
        return ""

    return f'''
    <div style="margin-bottom: 24px;">
        <h3 style="color: #374151; font-size: 18px; font-weight: 600; margin: 0 0 12px 0; display: flex; align-items: center;">
            <span style="background: #f59e0b; width: 3px; height: 18px; border-radius: 2px; margin-right: 8px;"></span>
            Примітки
        </h3>
        <div style="background: #fffbeb; border: 1px solid #f59e0b; border-radius: 8px; padding: 16px;">
            <div style="color: #92400e; line-height: 1.7; font-size: 15px;">
                {process_markdown(notes)}
            </div>
        </div>
    </div>
    '''

def get_unified_problem_content(problem_data, test_count):
    """Контент задачі без картки (для використання всередині стилізованого контейнера)"""
    code_style = get_code_style()

    # Завантажуємо приклади з тестових файлів
    examples = load_examples_from_tests(problem_data.get('id', ''))

    examples_html = ""
    for i, example in enumerate(examples, 1):
        examples_html += f'''
        <div style="margin: 16px 0;">
            <div style="font-weight: 600; color: #374151; margin-bottom: 8px;">Приклад {i}:</div>
            <div style="margin-bottom: 12px;">
                <div style="font-weight: 500; color: #6b7280; margin-bottom: 4px;">Вхід:</div>
                <pre style="{code_style}">{example['input']}</pre>
            </div>
            <div>
                <div style="font-weight: 500; color: #6b7280; margin-bottom: 4px;">Вихід:</div>
                <pre style="{code_style}">{example['output']}</pre>
            </div>
        </div>'''

    return f'''
        <!-- Заголовок задачі -->
        <div style="border-bottom: 2px solid #e5e7eb; padding-bottom: 16px; margin-bottom: 24px;">
            <h1 style="color: #1f2937; font-size: 28px; font-weight: 700; margin: 0; display: flex; align-items: center;">
                <span style="background: #3b82f6; color: white; width: 40px; height: 40px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; font-size: 18px; margin-right: 12px;">{problem_data.get('id', '')}</span>
                {problem_data['title']}
            </h1>
        </div>

        <!-- Умова задачі -->
        <div style="margin-bottom: 24px;">
            <h3 style="color: #374151; font-size: 18px; font-weight: 600; margin: 0 0 12px 0;">Умова задачі</h3>
            <div style="color: #4b5563; line-height: 1.7; font-size: 15px;">
                {process_markdown(problem_data['legend'])}
            </div>
        </div>

        <!-- Формати вводу та виводу -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px;">
            <div>
                <h3 style="color: #374151; font-size: 16px; font-weight: 600; margin: 0 0 8px 0;">Формат вводу</h3>
                <div style="color: #6b7280; line-height: 1.6; font-size: 14px;">
                    {process_markdown(problem_data.get('input_format', problem_data.get('input', '')))}
                </div>
            </div>
            <div>
                <h3 style="color: #374151; font-size: 16px; font-weight: 600; margin: 0 0 8px 0;">Формат виводу</h3>
                <div style="color: #6b7280; line-height: 1.6; font-size: 14px;">
                    {process_markdown(problem_data.get('output_format', problem_data.get('output', '')))}
                </div>
            </div>
        </div>

        {f'<div style="margin-bottom: 24px;"><h3 style="color: #374151; font-size: 18px; font-weight: 600; margin: 0 0 12px 0;">Приклади</h3>{examples_html}</div>' if examples_html else ''}

        {get_scoring_section(problem_data)}

        {get_notes_section(problem_data)}

        {get_test_download_section(problem_data.get('id', ''))}

        <div style="background: #f0f9ff; border: 1px solid #0ea5e9; border-radius: 8px; padding: 12px; margin-bottom: 32px;">
            <div style="color: #0c4a6e; font-weight: 500;">
                📊 Тестових випадків: {test_count} • Часовий ліміт: {problem_data.get('time_limit', 'Не вказано')} • Ліміт пам'яті: {problem_data.get('memory_limit', 'Не вказано')}
            </div>
        </div>

    '''

def get_unified_card_middle_section():
    """Середня частина об'єднаної картки (між завантаженням та результатами)"""
    return '''
        <!-- Розділювач -->
        <div style="border-top: 1px solid #e5e7eb; margin: 32px 0;"></div>

        <!-- Заголовок секції результатів -->
        <h3 style="color:#1f2937;font-size:20px;font-weight:600;margin:0 0 16px 0;display:flex;align-items:center;">
            <span style="background:#f59e0b;width:4px;height:20px;border-radius:2px;margin-right:10px;"></span>
            Результати
        </h3>
    '''

def get_unified_card_end():
    """Закриває об'єднану картку"""
    return '</div>'

def create_test_download_widgets(problem_id, contest_path='contest'):
    """Створює віджети для завантаження тестів"""
    import ipywidgets as widgets
    from IPython.display import display

    try:
        # Завантаження конфігурації тестування
        with open(f'{contest_path}/{problem_id}/tests/testing.json', 'r') as f:
            testing_config = json.load(f)

        test_files = []
        tests_dir = f'{contest_path}/{problem_id}/tests/tests'

        # Збір інформації про тести
        for block in testing_config['blocks']:
            block_id = block['block_id']
            block_name = "Приклади" if block_id == 0 else f"Блок {block_id}"

            for test in block['tests']:
                test_id = test['test_id']
                input_file = f"{block_id}-{test_id}.in"
                output_file = f"{block_id}-{test_id}.out"

                input_path = os.path.join(tests_dir, input_file)
                output_path = os.path.join(tests_dir, output_file)

                if os.path.exists(input_path) and os.path.exists(output_path):
                    test_files.append({
                        'block_name': block_name,
                        'block_id': block_id,
                        'test_id': test_id,
                        'input_file': input_file,
                        'output_file': output_file,
                        'input_path': input_path,
                        'output_path': output_path,
                        'display_name': f"{block_name} - Тест {test_id}" if block_id > 0 else f"Приклад {test_id}"
                    })

        if not test_files:
            return widgets.HTML("<div style='color: red;'>Тестові файли не знайдено</div>")

        # Функція завантаження файлу з браузера
        def download_file(file_path, filename):
            from IPython.display import Javascript
            import json as json_lib

            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()

                # Ескейпимо контент для JavaScript
                escaped_content = json_lib.dumps(content)

                # JavaScript для завантаження файлу
                download_js = f'''
                (function() {{
                    try {{
                        // Створюємо blob з контентом файлу
                        const content = {escaped_content};
                        const blob = new Blob([content], {{ type: 'text/plain;charset=utf-8' }});

                        // Створюємо URL для blob
                        const url = window.URL.createObjectURL(blob);

                        // Створюємо тимчасовий елемент для завантаження
                        const link = document.createElement('a');
                        link.href = url;
                        link.download = '{filename}';

                        // Додаємо до документу, клікаємо, видаляємо
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);

                        // Очищуємо URL
                        window.URL.revokeObjectURL(url);

                        console.log('Downloaded: {filename}');
                    }} catch (error) {{
                        console.error('Download failed:', error);
                        alert('Помилка завантаження файлу {filename}: ' + error.message);
                    }}
                }})();
                '''

                display(Javascript(download_js))

            except Exception as e:
                error_widget = widgets.HTML(f'''
                <div style="background: #fef2f2; border: 1px solid #ef4444; border-radius: 8px; padding: 12px; margin: 8px 0;">
                    <div style="color: #dc2626; font-weight: 500;">
                        ❌ Помилка завантаження файлу {filename}: {e}
                    </div>
                </div>
                ''')
                display(error_widget)

        # Створення віджетів для кожного блоку
        widgets_list = []
        current_block = None

        for test in test_files:
            # Додати заголовок блоку якщо це новий блок
            if current_block != test['block_id']:
                current_block = test['block_id']
                block_color = "#10b981" if test['block_id'] == 0 else "#3b82f6"

                block_header = widgets.HTML(f'''
                <div style="margin: 16px 0 8px 0;">
                    <div style="font-weight: 600; color: #374151; font-size: 16px; display: flex; align-items: center;">
                        <span style="background: {block_color}; width: 3px; height: 16px; border-radius: 2px; margin-right: 8px;"></span>
                        {test['block_name']}
                    </div>
                </div>
                ''')
                widgets_list.append(block_header)

            # Створити кнопки для завантаження
            test_label = widgets.HTML(f'''
            <div style="font-weight: 600; color: #374151; margin-bottom: 8px; font-size: 14px;">
                {test['display_name']}
            </div>
            ''')

            input_btn = widgets.Button(
                description='📥 Вхід',
                style={'button_color': '#3b82f6'},
                layout={'width': '100px', 'margin': '0 4px 0 0'}
            )

            output_btn = widgets.Button(
                description='📤 Вихід',
                style={'button_color': '#10b981'},
                layout={'width': '100px', 'margin': '0 4px 0 0'}
            )

            # Прив'язати обробники подій
            input_btn.on_click(lambda b, path=test['input_path'], name=test['input_file']: download_file(path, name))
            output_btn.on_click(lambda b, path=test['output_path'], name=test['output_file']: download_file(path, name))

            test_container = widgets.VBox([
                test_label,
                widgets.HBox([input_btn, output_btn])
            ], layout={'margin': '8px 0', 'padding': '12px', 'border': '1px solid #e2e8f0', 'border_radius': '8px'})

            widgets_list.append(test_container)

        # Створення колапсованої секції
        import uuid
        unique_id = str(uuid.uuid4())[:8]

        # Кнопка для розгортання/згортання
        toggle_button = widgets.Button(
            description='📁 Показати тести для завантаження',
            button_style='info',
            icon='chevron-down',
            layout=widgets.Layout(width='auto', margin='0 0 8px 0'),
            style={'font_weight': '600'}
        )

        # Контейнер з тестами (спочатку прихований)
        tests_container = widgets.VBox(
            [
                widgets.HTML('''
                <div style="background: #fffbeb; border: 1px solid #f59e0b; border-radius: 8px; padding: 12px; margin: 8px 0;">
                    <div style="color: #92400e; font-weight: 500; font-size: 14px;">
                        💡 Натисніть кнопки для завантаження тестових файлів у ваш браузер
                    </div>
                </div>
                ''')
            ] + widgets_list,
            layout=widgets.Layout(display='none')  # Спочатку приховано
        )

        # Стан розгортання
        is_expanded = False

        def toggle_tests(button):
            nonlocal is_expanded
            if is_expanded:
                # Згортаємо
                tests_container.layout.display = 'none'
                toggle_button.description = '📁 Показати тести для завантаження'
                toggle_button.icon = 'chevron-down'
                toggle_button.button_style = 'info'
                is_expanded = False
            else:
                # Розгортаємо
                tests_container.layout.display = 'block'
                toggle_button.description = '📁 Приховати тести'
                toggle_button.icon = 'chevron-up'
                toggle_button.button_style = ''
                is_expanded = True

        toggle_button.on_click(toggle_tests)

        # Основний заголовок
        main_header = widgets.HTML('''
        <div style="margin-bottom: 16px;">
            <h3 style="color: #374151; font-size: 18px; font-weight: 600; margin: 0 0 12px 0; display: flex; align-items: center;">
                <span style="background: #10b981; width: 4px; height: 18px; border-radius: 2px; margin-right: 8px;"></span>
                📥 Завантаження тестових файлів
            </h3>
        </div>
        ''')

        return widgets.VBox([
            main_header,
            toggle_button,
            tests_container
        ])

    except Exception as e:
        return widgets.HTML(f'''
        <div style="background: #fef2f2; border: 1px solid #ef4444; border-radius: 8px; padding: 12px;">
            <div style="color: #dc2626; font-weight: 500; font-size: 14px;">
                ⚠️ Не вдалося завантажити список тестів: {e}
            </div>
        </div>
        ''')

def get_test_download_section(problem_id, contest_path='contest'):
    """Генерує HTML секцію для завантаження тестів (deprecated - використовуйте create_test_download_widgets)"""
    return '''
    <div style="margin-bottom: 24px;">
    </div>
    '''

