"""
Interface Logic for Competition Programming System
Логіка інтерфейсу для системи змагань з програмування
"""

import json
import os
import datetime
import time
import zipfile
import sys
import ipywidgets as widgets
from IPython.display import display, HTML, Javascript
from ui_components import *

# Add shared folder to path for importing judge
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'shared'))
import judge

def log_to_file(message, log_file="competition_interface.log"):
    """Записати повідомлення в лог файл та вивести в консоль"""
    timestamp = datetime.datetime.now().strftime("%H:%M:%S")
    log_message = f"[{timestamp}] {message}"

    # Записати в файл
    try:
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(log_message + '\n')
    except Exception as e:
        print(f"❌ Error writing to log file: {e}")

    # Також вивести в консоль
    print(log_message)

class CompetitionInterface:
    """Основний клас інтерфейсу змагання"""

    def __init__(self, contest_path='contest'):
        # Initialize log file
        try:
            with open("competition_interface.log", 'w', encoding='utf-8') as f:
                f.write(f"=== Competition Interface Log Started at {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===\n")
        except Exception:
            pass  # Continue if can't create log file

        self.contest_path = contest_path
        self.current_problem = None
        self.uploaded_code = ""
        self.uploaded_filename = ""

        # Файл для збереження подач
        self.submissions_file = 'contest_submissions.json'
        self.submissions = self._load_submissions()

        # Флаг для відстеження показу повідомлення про подачу (показувати лише раз за сесію)
        self.submission_message_shown = False

        # Завантаження даних
        self.contest_info = judge.get_contest_info(contest_path)
        self.problems = judge.get_available_problems(contest_path)
        self.languages = judge.get_available_languages()
        self.current_language = judge.get_default_language()

        if self.problems:
            self.current_problem = self.problems[0]['id']

        # Створення віджетів
        self._create_widgets()
        self._setup_event_handlers()

    def _create_widgets(self):
        """Створення всіх віджетів інтерфейсу"""
        # Заголовок
        self.header = widgets.HTML(
            get_header_html(
                self.contest_info.get('name', 'Змагання з програмування'),
                len(self.problems),
                len(self.languages)
            )
        )

        # Кнопки задач + фінальна подача
        self.problem_buttons = []
        for i, problem in enumerate(self.problems):
            button = widgets.Button(
                description=f"{problem['id']}: {problem['name'][:20]}{'...' if len(problem['name']) > 20 else ''}",
                button_style='info' if i == 0 else '',
                layout=widgets.Layout(width='auto', margin='0 8px 8px 0'),
                style={'font_weight': '600' if i == 0 else '500'}
            )
            self.problem_buttons.append(button)

        # Додати кнопку фінальної подачі
        final_button = widgets.Button(
            description='🎯 Фінальна подача',
            button_style='',
            layout=widgets.Layout(width='auto', margin='0 8px 8px 0'),
            style={'font_weight': '500'}
        )
        self.problem_buttons.append(final_button)

        # Навігація задач
        self.problem_nav = widgets.HBox(
            self.problem_buttons,
            layout=widgets.Layout(margin='16px 0 24px 0', flex_wrap='wrap')
        )

        # Відображення задачі
        self.problem_display = widgets.Output()

        # Відображення фінальної подачі
        self.final_display = widgets.Output()

        # Поточний режим відображення ('problem' або 'final')
        self.current_mode = 'problem'

        # Селектор мови зі стилізацією (без description, додається в HTML)
        self.language_selector = widgets.Dropdown(
            options=self.languages,
            value=self.current_language,
            description='',
            layout=widgets.Layout(width='300px', height='40px', border='none', margin='0 0 8px 0'),
            style={'font_size': '14px'}
        )

        # Завантаження файлів зі стилізацією (без description, додається в HTML)
        self.file_upload = widgets.FileUpload(
            accept='',
            multiple=False,
            description='',
            layout=widgets.Layout(width='350px', height='40px', border='none', margin='0 0 8px 0'),
            style={'font_size': '14px'}
        )

        # Попередній перегляд коду зі стилізацією (створюється, але не відображається за замовчуванням)
        self.code_preview = widgets.Textarea(
            value='',
            placeholder='',
            description='',
            layout=widgets.Layout(width='100%', height='350px', border='1px solid #d1d5db', border_radius='8px'),
            style={'font_family': 'Monaco, Consolas, "Liberation Mono", "Courier New", monospace', 'font_size': '13px'},
            disabled=True
        )

        # Заголовок для коду (також створюється, але не відображається за замовчуванням)
        self.code_preview_header = widgets.HTML('<div style="margin: 20px 0 12px 0; border: none;"><div style="font-weight: 600; color: #374151; font-size: 16px; margin-bottom: 8px; display: flex; align-items: center; border: none;"><span style="margin-right: 8px;">💻</span>Попередній перегляд коду</div></div>')

        # Інформація про подачу
        self.submission_info = widgets.HTML()

        # Кнопки управління зі стилізацією
        self.test_button = widgets.Button(
            description='🚀 Запустити тести',
            button_style='success',
            layout=widgets.Layout(width='200px', height='45px', margin='0 8px 0 0'),
            style={'font_weight': '600', 'font_size': '14px'}
        )

        self.clear_button = widgets.Button(
            description='🗑️ Очистити код',
            button_style='',
            layout=widgets.Layout(width='160px', height='45px'),
            style={'font_weight': '500', 'font_size': '14px'}
        )


        # Результати
        self.results_output = widgets.Output()

        # Контейнер для віджетів завантаження тестів
        self.test_download_container = widgets.VBox([], layout=widgets.Layout(margin='0'))

        # Фінальна подача
        self._create_final_submission_widgets()

    def _create_final_submission_widgets(self):
        """Створення віджетів для фінальної подачі"""
        # Словники для зберігання віджетів кожної задачі
        self.final_uploads = {}
        self.final_languages = {}
        self.final_codes = {}
        self.final_filenames = {}
        self.final_status_displays = {}

        # Створити віджети для кожної задачі
        for problem in self.problems:
            problem_id = problem['id']

            # Завантаження файлу для цієї задачі (стиль як у основному інтерфейсі)
            file_upload = widgets.FileUpload(
                accept='',
                multiple=False,
                description='',
                layout=widgets.Layout(width='350px', height='40px', border='none', margin='0 0 8px 0'),
                style={'font_size': '14px'}
            )

            # Селектор мови для цієї задачі (стиль як у основному інтерфейсі)
            language_selector = widgets.Dropdown(
                options=self.languages,
                value=self.current_language,
                description='',
                layout=widgets.Layout(width='300px', height='40px', border='none', margin='0 0 8px 0'),
                style={'font_size': '14px'}
            )

            # Статус для цієї задачі
            status_display = widgets.HTML()

            # Збереження посилань
            self.final_uploads[problem_id] = file_upload
            self.final_languages[problem_id] = language_selector
            self.final_codes[problem_id] = ""
            self.final_filenames[problem_id] = ""
            self.final_status_displays[problem_id] = status_display

        # Кнопка генерації фінального ZIP (стиль як у основному інтерфейсі)
        self.generate_final_button = widgets.Button(
            description='🎯 Згенерувати фінальну подачу',
            button_style='success',
            layout=widgets.Layout(width='200px', height='45px', margin='0 8px 0 0'),
            style={'font_weight': '600', 'font_size': '14px'}
        )

        # Кнопка очищення всіх файлів
        self.clear_all_button = widgets.Button(
            description='🗑️ Очистити все',
            button_style='',
            layout=widgets.Layout(width='160px', height='45px'),
            style={'font_weight': '500', 'font_size': '14px'}
        )

        # Кнопка завантаження ZIP архіву
        self.download_zip_button = widgets.Button(
            description='📥 Завантажити ZIP',
            button_style='primary',
            layout=widgets.Layout(width='200px', height='45px', margin='0 8px 0 0'),
            style={'font_weight': '600', 'font_size': '14px'}
        )
        self.download_zip_button.layout.visibility = 'hidden'  # Спочатку сховано

        # Друга кнопка завантаження ZIP архіву (після результатів)
        self.download_zip_button_after = widgets.Button(
            description='📥 Завантажити ZIP',
            button_style='primary',
            layout=widgets.Layout(width='200px', height='45px', margin='16px 0 0 0'),
            style={'font_weight': '600', 'font_size': '14px'}
        )
        self.download_zip_button_after.layout.visibility = 'hidden'  # Спочатку сховано

        # Статус генерації
        self.final_status = widgets.HTML()

        # Результат фінальної подачі
        self.final_output = widgets.Output()

        # Змінна для зберігання імені ZIP файлу
        self.current_zip_filename = None

    def _setup_event_handlers(self):
        """Налаштування обробників подій"""
        # Кнопки задач
        for button in self.problem_buttons:
            button.on_click(self._on_problem_click)

        # Селектор мови
        self.language_selector.observe(self._on_language_change, names='value')

        # Завантаження файлів - стандартна обробка
        self.file_upload.observe(self._on_file_upload, names='value')

        # Кнопки управління
        self.test_button.on_click(self._on_test_click)
        self.clear_button.on_click(self._on_clear_click)

        # Фінальна подача - обробники завантаження файлів
        for problem_id, upload_widget in self.final_uploads.items():
            upload_widget.observe(lambda change, pid=problem_id: self._on_final_upload(change, pid), names='value')

        # Кнопка генерації фінальної подачі
        self.generate_final_button.on_click(self._on_generate_final)
        self.clear_all_button.on_click(self._on_clear_all_final)
        self.download_zip_button.on_click(self._on_download_zip)
        self.download_zip_button_after.on_click(self._on_download_zip)

    def _setup_download_functionality(self):
        """Налаштування функціоналу завантаження тестів"""
        from IPython.display import Javascript

        # JavaScript для встановлення глобальної функції завантаження
        download_js = f'''
        window.downloadTestFromPython = function(contestPath, problemId, filename) {{
            // Create a unique callback name
            const callbackName = 'downloadCallback_' + Math.random().toString(36).substr(2, 9);

            // Set up the callback
            window[callbackName] = function(content) {{
                try {{
                    // Create blob and download
                    const blob = new Blob([content], {{type: 'text/plain'}});
                    const url = window.URL.createObjectURL(blob);

                    const link = document.createElement('a');
                    link.href = url;
                    link.download = filename;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);

                    // Clean up
                    window.URL.revokeObjectURL(url);
                    delete window[callbackName];

                    console.log('Downloaded:', filename);
                }} catch (error) {{
                    console.error('Download failed:', error);
                    alert('Помилка завантаження: ' + error.message);
                    delete window[callbackName];
                }}
            }};

            // Call Python function via kernel
            const code = `
import os
from IPython.display import Javascript
from IPython.core.display import display

try:
    file_path = os.path.join("${{contestPath}}", "${{problemId}}", "tests", "tests", "${{filename}}")
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Escape content for JavaScript
    escaped_content = repr(content)

    # Execute callback
    js_code = f"window.${{callbackName}}({{escaped_content}});"
    display(Javascript(js_code))
except Exception as e:
    js_code = f"alert('Помилка читання файлу: {{str(e)}}'); delete window.${{callbackName}};"
    display(Javascript(js_code))
`;

            // Execute the Python code
            if (window.IPython && window.IPython.notebook) {{
                window.IPython.notebook.kernel.execute(code);
            }} else {{
                alert('Kernel недоступний. Перезапустіть notebook.');
            }}
        }};

        // Simplified ZIP download - no longer needed with direct HTML approach
        console.log('ZIP download using direct HTML data URLs');
        console.log('Test download functionality initialized');
        '''

        display(Javascript(download_js))

    def _download_test_file(self, contest_path, problem_id, filename):
        """Завантаження тестового файлу"""
        try:
            import os
            from IPython.display import Javascript

            file_path = os.path.join(contest_path, problem_id, "tests", "tests", filename)

            if not os.path.exists(file_path):
                return f"alert('Файл не знайдено: {filename}');"

            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # Escape content for JavaScript
            escaped_content = repr(content)

            # Create download JavaScript
            js_code = f'''
                try {{
                    const blob = new Blob([{escaped_content}], {{type: 'text/plain'}});
                    const url = window.URL.createObjectURL(blob);

                    const link = document.createElement('a');
                    link.href = url;
                    link.download = '{filename}';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);

                    // Clean up
                    window.URL.revokeObjectURL(url);
                    console.log('Downloaded: {filename}');
                }} catch (error) {{
                    console.error('Download failed:', error);
                    alert('Помилка завантаження: ' + error.message);
                }}
            '''

            display(Javascript(js_code))
            log_to_file(f"📥 Завантажено тестовий файл: {filename}")

        except Exception as e:
            error_js = f"alert('Помилка завантаження файлу {filename}: {str(e)}');"
            display(Javascript(error_js))
            log_to_file(f"❌ Помилка завантаження {filename}: {e}")

    def _trigger_mathjax_rendering(self):
        """Запуск MathJax для обробки LaTeX контенту"""
        mathjax_js = '''
        setTimeout(function() {
            if (window.MathJax && window.MathJax.typesetPromise) {
                window.MathJax.typesetPromise().then(() => {
                    console.log('MathJax re-rendering completed');
                }).catch((err) => {
                    console.error('MathJax re-rendering error:', err);
                });
            }
        }, 100); // Small delay to ensure DOM is updated
        '''
        display(Javascript(mathjax_js))

    def _load_submissions(self):
        """Завантаження попередніх подач з JSON файлу"""
        try:
            if os.path.exists(self.submissions_file):
                with open(self.submissions_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                # Створити файл з порожнім списком якщо не існує
                empty_submissions = []
                with open(self.submissions_file, 'w', encoding='utf-8') as f:
                    json.dump(empty_submissions, f, ensure_ascii=False, indent=2)
                return empty_submissions
        except (json.JSONDecodeError, IOError) as e:
            print(f"⚠️ Помилка завантаження файлу подач: {e}")
            return []

    def _save_submissions(self):
        """Збереження подач у JSON файл"""
        try:
            with open(self.submissions_file, 'w', encoding='utf-8') as f:
                json.dump(self.submissions, f, ensure_ascii=False, indent=2)
        except IOError as e:
            print(f"⚠️ Помилка збереження файлу подач: {e}")

    def _add_submission(self, result_json):
        """Додавання нової подачі до списку (без збереження тестових результатів)"""
        submission = {
            'unix': time.time_ns(),
            'problem': self.current_problem,
            'language': self.current_language,
            'filename': self.uploaded_filename,
            'code': self.uploaded_code,
            'submission_number': len(self.submissions) + 1
        }
        # Не зберігаємо тестові результати в contest_submissions.json
        # Зберігаємо лише метадані подачі
        self.submissions.append(submission)
        self._save_submissions()

    def _clear_file_upload(self):
        """Очищення віджету завантаження файлів"""
        self.uploaded_code = ""
        self.uploaded_filename = ""
        self.code_preview.value = ""

        # Створити новий FileUpload widget для повного очищення
        new_file_upload = widgets.FileUpload(
            accept='',
            multiple=False,
            description='',
            layout=widgets.Layout(width='350px', height='40px', border='none', margin='0 0 8px 0'),
            style={'font_size': '14px'}
        )

        # Знайти індекс старого file_upload widget в base_content
        file_upload_index = None
        for i, widget in enumerate(self.base_content):
            if widget is self.file_upload:
                file_upload_index = i
                break

        # Замінити старий widget на новий
        if file_upload_index is not None:
            self.base_content[file_upload_index] = new_file_upload

            # Відключити observer від старого widget
            self.file_upload.unobserve(self._on_file_upload, names='value')

            # Замінити посилання на новий widget
            self.file_upload = new_file_upload

            # Підключити observer до нового widget
            self.file_upload.observe(self._on_file_upload, names='value')

            # Оновити layout якщо content_vbox існує
            if hasattr(self, 'content_vbox'):
                self.content_vbox.children = self.base_content + self.after_upload_content

        self._hide_code_preview()
        self._update_submission_info()

    def _show_code_preview(self):
        """Показати попередній перегляд коду"""
        current_children = list(self.content_vbox.children)

        # Перевіряємо чи вже відображається код
        if self.code_preview_header not in current_children:
            # Знаходимо позицію після submission_info
            submission_info_index = current_children.index(self.submission_info)

            # Вставляємо заголовок та код після submission_info
            current_children.insert(submission_info_index + 1, self.code_preview_header)
            current_children.insert(submission_info_index + 2, self.code_preview)

            self.content_vbox.children = current_children

    def _hide_code_preview(self):
        """Сховати попередній перегляд коду"""
        current_children = list(self.content_vbox.children)

        # Видаляємо заголовок та код якщо присутні
        if self.code_preview_header in current_children:
            current_children.remove(self.code_preview_header)
        if self.code_preview in current_children:
            current_children.remove(self.code_preview)

        self.content_vbox.children = current_children

    def _update_all_final_statuses(self):
        """Оновлення статусів всіх задач фінальної подачі"""
        for problem_id, status_widget in self.final_status_displays.items():
            if self.final_codes[problem_id]:
                filename = self.final_filenames[problem_id]
                lines = len(self.final_codes[problem_id].split('\n'))
                chars = len(self.final_codes[problem_id])
                status_widget.value = f'''
                <div style="background: #f0fdf4; border: 1px solid #10b981; border-radius: 6px; padding: 8px 12px; margin: 8px 0; display: flex; align-items: center;">
                    <span style="color: #10b981; font-size: 16px; margin-right: 8px;">✅</span>
                    <div>
                        <div style="color: #065f46; font-weight: 600; font-size: 14px;">Файл завантажено успішно</div>
                        <div style="color: #059669; font-size: 12px; margin-top: 2px;">
                            📄 <strong>{filename}</strong> • {lines} рядків • {chars} символів
                        </div>
                    </div>
                </div>'''
            else:
                status_widget.value = f'''
                <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 12px; margin: 8px 0; display: flex; align-items: center;">
                    <span style="color: #64748b; font-size: 16px; margin-right: 8px;">📁</span>
                    <div style="color: #64748b; font-size: 14px;">
                        Оберіть файл з кодом для <strong>Задачі {problem_id}</strong>
                    </div>
                </div>'''

    def _clear_all_final_files(self):
        """Очищення всіх завантажених файлів фінальної подачі"""
        for problem_id in self.final_codes.keys():
            self.final_codes[problem_id] = ""
            self.final_filenames[problem_id] = ""

        self._update_all_final_statuses()
        self.final_status.value = ""
        self.final_output.clear_output()

        # Сховати кнопки завантаження та очистити ім'я ZIP файлу
        self.download_zip_button.layout.visibility = 'hidden'
        self.download_zip_button_after.layout.visibility = 'hidden'
        self.current_zip_filename = None

    def _update_submission_info(self):
        """Оновлення інформації про подачу з покращеним стилем"""
        if self.uploaded_code:
            lines = len(self.uploaded_code.split('\n'))
            chars = len(self.uploaded_code)
            self.submission_info.value = f'''
            <div style="background: #f0fdf4; border: 1px solid #10b981; border-radius: 6px; padding: 8px 12px; margin: 8px 0; display: flex; align-items: center;">
                <span style="color: #10b981; font-size: 16px; margin-right: 8px;">✅</span>
                <div>
                    <div style="color: #065f46; font-weight: 600; font-size: 14px;">Файл завантажено успішно</div>
                    <div style="color: #059669; font-size: 12px; margin-top: 2px;">
                        📄 <strong>{self.uploaded_filename}</strong> • {lines} рядків • {chars} символів
                    </div>
                </div>
            </div>'''
            self._show_code_preview()
        else:
            self.submission_info.value = f'''
            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 12px; margin: 8px 0; display: flex; align-items: center;">
                <span style="color: #64748b; font-size: 16px; margin-right: 8px;">📁</span>
                <div style="color: #64748b; font-size: 14px;">
                    Оберіть файл з кодом для <strong>Задачі {self.current_problem}</strong> (<em>{self.current_language}</em>)
                </div>
            </div>'''

    def _show_problem(self, problem_id):
        """Відображення задачі"""
        try:
            with open(f'{self.contest_path}/{problem_id}/problem.json', 'r') as f:
                problem = json.load(f)

            # Підрахунок тестів з testing.json
            test_count = 0
            try:
                with open(f'{self.contest_path}/{problem_id}/tests/testing.json', 'r') as f:
                    testing_config = json.load(f)
                    for block in testing_config['blocks']:
                        test_count += len(block['tests'])
            except Exception:
                # Fallback: спробувати порахувати файли в директорії
                try:
                    test_files = os.listdir(f'{self.contest_path}/{problem_id}/tests/tests')
                    test_count = len([f for f in test_files if f.endswith('.in')])
                except Exception:
                    test_count = 0

            # Додавання ID до даних задачі
            problem['id'] = problem_id

            # Оновлення контенту задачі (без картки, оскільки VBox має card styling)
            self.problem_content_html.value = get_unified_problem_content(problem, test_count)

            # Додавання віджетів для завантаження тестів
            self._show_test_download_widgets(problem_id)

        except Exception as e:
            # В разі помилки показати помилку (без картки, оскільки VBox має card styling)
            error_content = f'''
                <div style="color: #dc2626; font-weight: 500;">⚠️ Помилка завантаження задачі {problem_id}: {e}</div>
            '''
            self.problem_content_html.value = error_content
            self._clear_test_download_widgets()

    def _show_test_download_widgets(self, problem_id):
        """Показує віджети для завантаження тестів"""
        try:
            from ui_components import create_test_download_widgets

            # Очистити попередні віджети
            self._clear_test_download_widgets()

            # Створити нові віджети для завантаження тестів
            test_widgets = create_test_download_widgets(problem_id, self.contest_path)

            # Додати до контейнера тестових віджетів
            if hasattr(self, 'test_download_container'):
                self.test_download_container.children = [test_widgets]
        except Exception as e:
            print(f"Помилка створення віджетів завантаження тестів: {e}")

    def _clear_test_download_widgets(self):
        """Очищає віджети завантаження тестів"""
        if hasattr(self, 'test_download_container'):
            self.test_download_container.children = []

    def _show_final_submission(self):
        """Відображення інтерфейсу фінальної подачі"""
        # Оновити статуси всіх задач
        self._update_all_final_statuses()

        # Створення заголовка фінальної подачі
        header_html = widgets.HTML(f'''
            <h2 style="color: #1f2937; font-size: 28px; font-weight: 700; margin: 0 0 8px 0; display: flex; align-items: center;">
                🎯 Фінальна подача
            </h2>
            <p style="color: #6b7280; font-size: 16px; margin: 0 0 24px 0; line-height: 1.5;">
                Завантажте рішення для задач, які ви хочете подати, та створіть ZIP архів. Подача рішень необов'язкова для всіх задач.
            </p>
        ''')

        # Створюємо секції для кожної задачі
        problem_sections = []
        for i, problem in enumerate(self.problems):
            problem_id = problem['id']
            problem_name = problem['name']

            # Секція для кожної задачі
            problem_section = [
                # Заголовок задачі
                widgets.HTML(f'''
                    <div style="border-top: {'2px solid #e5e7eb' if i > 0 else 'none'}; margin: {'32px 0 24px 0' if i > 0 else '0 0 24px 0'}; padding-top: {'24px' if i > 0 else '0'};">
                        <h3 style="color: #1f2937; font-size: 20px; font-weight: 600; margin: 0 0 16px 0; display: flex; align-items: center;">
                            <span style="background: #3b82f6; color: white; width: 32px; height: 32px; border-radius: 6px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 600; margin-right: 12px;">{problem_id}</span>
                            {problem_name}
                        </h3>
                    </div>
                '''),

                # Селектор мови
                widgets.HTML('<div style="font-weight: 600; color: #374151; font-size: 14px; margin: 8px 0 6px 0;">🔧 Мова програмування</div>'),
                self.final_languages[problem_id],

                # Завантаження файлу
                widgets.HTML('<div style="font-weight: 600; color: #374151; font-size: 14px; margin: 16px 0 6px 0;">📂 Завантажити файл</div>'),
                self.final_uploads[problem_id],

                # Статус завантаження
                self.final_status_displays[problem_id],
            ]
            problem_sections.extend(problem_section)

        # Створюємо основний контент (як в problem page)
        final_content_vbox = widgets.VBox([
            header_html,

            # Секції всіх задач
            *problem_sections,

            # Кнопки управління (як в problem page)
            widgets.HBox([self.generate_final_button, self.clear_all_button, self.download_zip_button],
                        layout=widgets.Layout(justify_content='flex-start', margin='32px 0 8px 0')),

            # Статус генерації
            self.final_status,

            # Розділювач та заголовок результатів (як в problem page)
            widgets.HTML(get_unified_card_middle_section()),

            # Результати
            self.final_output,

            # Друга кнопка завантаження ZIP (після результатів)
            self.download_zip_button_after,
        ])

        # Додаємо CSS клас для білого card стилю (як в problem page)
        final_content_vbox.add_class('problem-card')

        # Створюємо фінальний контент з CSS стилями (як в problem page)
        final_content = widgets.VBox([
            # Використовуємо ті самі CSS стилі що й для problem page
            widgets.HTML('''<style>
                .problem-card {
                    background: white;
                    border: 1px solid #e5e7eb;
                    border-radius: 12px;
                    padding: 24px;
                    margin: 16px 0;
                    box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
                }
                .problem-card .widget-dropdown select {
                    background: #f9fafb !important;
                    border: 1px solid #d1d5db !important;
                    border-radius: 6px;
                    padding: 8px 12px;
                    font-size: 14px;
                    color: #374151 !important;
                    font-weight: 500;
                }
                .problem-card .widget-upload {
                    background: #f8fafc !important;
                    border: 2px dashed #cbd5e0 !important;
                    border-radius: 8px;
                    padding: 16px 12px;
                    text-align: center;
                }
                .problem-card .widget-upload,
                .problem-card .widget-upload * {
                    color: #374151 !important;
                    font-weight: 500 !important;
                }
            </style>'''),
            final_content_vbox
        ])

        # Оновити content_area для відображення фінальної подачі
        if hasattr(self, 'content_area'):
            self.content_area.children = [final_content]

    def _on_problem_click(self, button):
        """Обробник кліку по кнопці задачі або фінальної подачі"""
        for i, prob_button in enumerate(self.problem_buttons):
            if prob_button == button:
                # Останній button це фінальна подача
                is_final_submission = (i == len(self.problem_buttons) - 1)

                if is_final_submission:
                    self.current_mode = 'final'
                    self._show_final_submission()
                else:
                    self.current_mode = 'problem'
                    self.current_problem = self.problems[i]['id']
                    print(f"📋 Перейшли до задачі {self.current_problem}")
                    # Перемкнути content_area назад до problem_content
                    if hasattr(self, 'content_area'):
                        self.content_area.children = [self.problem_content]
                    self._show_problem(self.current_problem)
                    self._update_submission_info()

                # Оновлення стилів кнопок
                for j, btn in enumerate(self.problem_buttons):
                    if j == i:
                        btn.button_style = 'info'
                        btn.style = {'font_weight': '600'}
                    else:
                        btn.button_style = ''
                        btn.style = {'font_weight': '500'}
                break

        self.results_output.clear_output()

    def _on_language_change(self, change):
        """Обробник зміни мови"""
        self.current_language = change['new']
        self._update_submission_info()

    def _on_file_upload(self, change):
        """Обробник завантаження файлу (підтримує tuple та dict формати)"""
        try:
            if change['type'] == 'change' and change['name'] == 'value':
                uploaded_files = change['new']

                if uploaded_files:
                    # Завжди обробляємо файли, навіть якщо це той самий файл
                    self._process_uploaded_files(uploaded_files)
                else:
                    # Файли очищені
                    self.uploaded_code = ""
                    self.uploaded_filename = ""
                    self.code_preview.value = ""
                    self._update_submission_info()

        except Exception as e:
            self.uploaded_code = ""
            self.uploaded_filename = ""
            self.code_preview.value = ""
            self._update_submission_info()


    def _process_uploaded_files(self, uploaded_files):
        """Безпосередня обробка завантажених файлів (підтримує tuple та dict формати)"""
        if not uploaded_files:
            return

        try:
            # Handle tuple format (PyCharm Jupyter)
            if isinstance(uploaded_files, tuple):
                if len(uploaded_files) == 0:
                    return

                file_info = uploaded_files[0]  # Get first file from tuple
                self.uploaded_filename = file_info.get('name', 'unknown_file')

            # Handle dictionary format (standard Jupyter)
            elif isinstance(uploaded_files, dict):
                file_info = list(uploaded_files.values())[0]
                self.uploaded_filename = list(uploaded_files.keys())[0]

            else:
                return

            # Process content
            if 'content' in file_info:
                content = file_info['content']

                # Handle different content types
                if isinstance(content, bytes):
                    self.uploaded_code = content.decode('utf-8')
                elif isinstance(content, str):
                    self.uploaded_code = content
                elif hasattr(content, 'tobytes'):  # Memory object
                    self.uploaded_code = content.tobytes().decode('utf-8')
                elif hasattr(content, 'read'):  # File-like object
                    self.uploaded_code = content.read().decode('utf-8')
                else:
                    self.uploaded_code = str(content)

                self.code_preview.value = self.uploaded_code
                self._update_submission_info()

        except Exception as e:
            pass

    def _on_test_click(self, button):
        """Обробник тестування (стабільна версія)"""
        if not self.uploaded_code.strip():
            self.results_output.clear_output()
            with self.results_output:
                display(HTML(get_error_html('Спочатку завантажте файл з кодом!')))
            return

        # Зберегти код та назву файлу для тестування
        code_for_testing = self.uploaded_code
        filename_for_testing = self.uploaded_filename

        # Вимкнути кнопку під час тестування
        self.test_button.disabled = True
        self.test_button.description = '⏳ Тестування...'

        # Очистити попередній перегляд файлу та інформацію
        self._clear_file_upload()

        # Показати стан "подача в обробці"
        self.results_output.clear_output(wait=True)
        with self.results_output:
            display(HTML(get_pending_submission_html()))

        try:
            # Запуск тестів з публічними блоками (для учасників)
            result = judge.test_solution_with_public_blocks(
                self.current_problem,
                self.current_language,
                code_for_testing,
                self.contest_path
            )

            # Обробка результатів для відображення (з повними деталями)
            if hasattr(result, 'to_dict'):
                result_json_full = result.to_dict()
            else:
                result_json_full = result

            # Обробка результатів для збереження (без деталей тестів)
            if hasattr(result, 'to_dict_clean'):
                result_json_clean = result.to_dict_clean()
            else:
                result_json_clean = result_json_full

            # Збереження подачі в JSON файл (БЕЗ input/expected/actual)
            self._add_submission(result_json_clean)

            # Замінити стан "в обробці" на результати тестування
            self.results_output.clear_output()
            with self.results_output:
                # Використовуємо блокову версію, якщо є дані про блоки
                if 'blocks' in result_json_full:
                    from ui_components import get_block_results_html
                    display(HTML(get_block_results_html(result_json_full)))
                else:
                    display(HTML(get_results_html(result_json_full)))

            # Увімкнути кнопку після завершення тестування
            self.test_button.disabled = False
            self.test_button.description = '🚀 Запустити тести'

            # Файл було очищено після тестування - потрібно завантажити новий для повторного тестування

        except Exception as e:
            # Також зберігаємо неуспішні спроби
            error_result = {
                'verdict': 'ERROR',
                'passed_tests': 0,
                'total_tests': 0,
                'total_time': 0.0,
                'compile_error': str(e)
            }
            self._add_submission(error_result)

            # Замінити стан "в обробці" на помилку
            self.results_output.clear_output()
            with self.results_output:
                display(HTML(get_error_html(f'Системна помилка: {e}')))

            # Увімкнути кнопку після помилки
            self.test_button.disabled = False
            self.test_button.description = '🚀 Запустити тести'

            # Файл було очищено після тестування - потрібно завантажити новий для виправлення та повторного тестування

    def _on_clear_click(self, button):
        """Обробник очищення"""
        self._clear_file_upload()
        self.results_output.clear_output()

    def _on_clear_all_final(self, button):
        """Обробник очищення всіх файлів фінальної подачі"""
        self._clear_all_final_files()

    def _on_download_zip(self, button):
        """Обробник завантаження ZIP архіву"""
        import os
        if self.current_zip_filename and os.path.exists(self.current_zip_filename):
            try:
                from IPython.display import Javascript
                import base64

                # Читаємо ZIP файл
                with open(self.current_zip_filename, 'rb') as f:
                    zip_data = f.read()

                # Кодуємо в base64
                b64_data = base64.b64encode(zip_data).decode()

                # Отримуємо ім'я файлу
                filename = os.path.basename(self.current_zip_filename)

                # JavaScript для автоматичного завантаження
                js_code = f'''
                (function() {{
                    // Створюємо blob з ZIP даних
                    const binaryString = atob("{b64_data}");
                    const bytes = new Uint8Array(binaryString.length);
                    for (let i = 0; i < binaryString.length; i++) {{
                        bytes[i] = binaryString.charCodeAt(i);
                    }}

                    const blob = new Blob([bytes], {{type: 'application/zip'}});
                    const url = window.URL.createObjectURL(blob);

                    // Створюємо та автоматично клікаємо посилання
                    const link = document.createElement('a');
                    link.href = url;
                    link.download = "{filename}";
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);

                    // Очищуємо URL
                    window.URL.revokeObjectURL(url);
                }})();
                '''

                display(Javascript(js_code))

                # Показати повідомлення про подачу після завантаження (тільки перший раз)
                if not self.submission_message_shown:
                    self._show_submission_message()
                else:
                    # Для повторних завантажень - коротке підтвердження
                    print(f"✅ ZIP архів {filename} завантажено!")

            except Exception as e:
                print(f"❌ Помилка завантаження ZIP файлу: {e}")
        else:
            print("❌ ZIP файл не знайдено або не створено")

    def _show_submission_message(self):
        """Показати повідомлення про подачу ZIP архіву (тільки один раз за сесію)"""
        # Перевіряємо чи вже показували це повідомлення
        if self.submission_message_shown:
            return

        # Позначаємо що повідомлення показано
        self.submission_message_shown = True

        from IPython.display import HTML

        submission_form_url = self.contest_info.get('submission_form')

        if submission_form_url:
            submission_html = f'''
            <div style="margin: 16px 0; padding: 20px; background: #eff6ff; border: 2px solid #3b82f6; border-radius: 12px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                <h3 style="margin: 0 0 16px 0; color: #1e40af; font-size: 20px; font-weight: 700; display: flex; align-items: center;">
                    📤 Наступний крок: Подача архіву
                </h3>
                <div style="background: white; padding: 16px; border-radius: 8px; border-left: 4px solid #3b82f6;">
                    <p style="margin: 0 0 16px 0; color: #1f2937; font-size: 16px; font-weight: 500;">
                        ZIP архів завантажено! Тепер подайте його через офіційну форму:
                    </p>
                    <a href="{submission_form_url}"
                       target="_blank"
                       style="display: inline-block; padding: 14px 28px; background: #3b82f6; color: white; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px; transition: background 0.2s;">
                        🔗 Відкрити форму подачі
                    </a>
                    <p style="margin: 16px 0 0 0; color: #6b7280; font-size: 14px;">
                        💡 <strong>Підказка:</strong> Завантажте ZIP файл, який щойно скачався, у форму подачі.
                    </p>
                </div>
            </div>
            '''
            display(HTML(submission_html))
        else:
            # Fallback якщо немає форми подачі
            fallback_html = '''
            <div style="margin: 16px 0; padding: 16px; background: #f0fdf4; border: 1px solid #10b981; border-radius: 8px;">
                <h4 style="margin: 0 0 8px 0; color: #065f46;">✅ ZIP архів завантажено!</h4>
                <p style="margin: 0; color: #059669;">Подайте завантажений архів відповідно до інструкцій змагання.</p>
            </div>
            '''
            display(HTML(fallback_html))

    def _get_problem_max_score(self, problem_id):
        """Отримання максимально можливого балу для задачі з конфігурації"""
        try:
            import json
            import os

            # Спробуємо спочатку private tests (повна система балів)
            private_config_path = os.path.join(self.contest_path, problem_id, 'private-tests', 'testing.json')
            if os.path.exists(private_config_path):
                with open(private_config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)

                max_score = 0
                for block in config.get('blocks', []):
                    for test in block.get('tests', []):
                        max_score += test.get('score', 0)
                return max_score

            # Якщо немає private tests, спробуємо public tests
            public_config_path = os.path.join(self.contest_path, problem_id, 'tests', 'testing.json')
            if os.path.exists(public_config_path):
                with open(public_config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)

                max_score = 0
                for block in config.get('blocks', []):
                    for test in block.get('tests', []):
                        max_score += test.get('score', 0)
                return max_score

        except Exception:
            pass

        return 0  # Якщо не вдається отримати - немає блокової системи

    def _get_problem_test_count(self, problem_id):
        """Отримання загальної кількості тестів для задачі з конфігурації"""
        try:
            import json
            import os

            # Спробуємо спочатку private tests
            private_config_path = os.path.join(self.contest_path, problem_id, 'private-tests', 'testing.json')
            if os.path.exists(private_config_path):
                with open(private_config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)

                test_count = 0
                for block in config.get('blocks', []):
                    test_count += len(block.get('tests', []))
                return test_count

            # Якщо немає private tests, спробуємо public tests
            public_config_path = os.path.join(self.contest_path, problem_id, 'tests', 'testing.json')
            if os.path.exists(public_config_path):
                with open(public_config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)

                test_count = 0
                for block in config.get('blocks', []):
                    test_count += len(block.get('tests', []))
                return test_count

        except Exception:
            pass

        return 0  # Якщо не вдається отримати

    def _on_final_upload(self, change, problem_id):
        """Обробник завантаження файлу для фінальної подачі (підтримує tuple та dict формати)"""
        if change['type'] == 'change' and change['name'] == 'value':
            uploaded_files = change['new']
            status_widget = self.final_status_displays[problem_id]

            if uploaded_files:
                try:
                    # Handle tuple format (PyCharm Jupyter)
                    if isinstance(uploaded_files, tuple):
                        file_info = uploaded_files[0]  # Get first file from tuple
                        filename = file_info.get('name', 'unknown_file')

                    # Handle dictionary format (standard Jupyter)
                    elif isinstance(uploaded_files, dict):
                        file_info = list(uploaded_files.values())[0]
                        filename = list(uploaded_files.keys())[0]

                    else:
                        raise ValueError(f"Unknown file format: {type(uploaded_files)}")

                    # Process content
                    content = file_info['content']

                    # Handle different content types
                    if isinstance(content, bytes):
                        code = content.decode('utf-8')
                    elif isinstance(content, str):
                        code = content
                    elif hasattr(content, 'tobytes'):  # Memory object
                        code = content.tobytes().decode('utf-8')
                    elif hasattr(content, 'read'):  # File-like object
                        code = content.read().decode('utf-8')
                    else:
                        code = str(content)

                    self.final_codes[problem_id] = code
                    self.final_filenames[problem_id] = filename

                    # Оновлення статусу (використовуємо той самий стиль що й для основних задач)
                    lines = len(code.split('\n'))
                    chars = len(code)
                    status_widget.value = f'''
                    <div style="background: #f0fdf4; border: 1px solid #10b981; border-radius: 6px; padding: 8px 12px; margin: 8px 0; display: flex; align-items: center;">
                        <span style="color: #10b981; font-size: 16px; margin-right: 8px;">✅</span>
                        <div>
                            <div style="color: #065f46; font-weight: 600; font-size: 14px;">Файл завантажено успішно</div>
                            <div style="color: #059669; font-size: 12px; margin-top: 2px;">
                                📄 <strong>{filename}</strong> • {lines} рядків • {chars} символів
                            </div>
                        </div>
                    </div>'''

                except Exception as e:
                    log_to_file(f"❌ Final upload error for {problem_id}: {e}")
                    self.final_codes[problem_id] = ""
                    self.final_filenames[problem_id] = ""
                    status_widget.value = f'''
                    <div style="background: #fef2f2; border: 1px solid #ef4444; border-radius: 6px; padding: 8px 12px; margin: 8px 0; display: flex; align-items: center;">
                        <span style="color: #ef4444; font-size: 16px; margin-right: 8px;">❌</span>
                        <div style="color: #dc2626; font-weight: 500; font-size: 14px;">
                            Помилка завантаження: {e}
                        </div>
                    </div>'''
            else:
                # Файл видалено
                self.final_codes[problem_id] = ""
                self.final_filenames[problem_id] = ""
                status_widget.value = f'''
                <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 12px; margin: 8px 0; display: flex; align-items: center;">
                    <span style="color: #64748b; font-size: 16px; margin-right: 8px;">📁</span>
                    <div style="color: #64748b; font-size: 14px;">
                        Оберіть файл з кодом для <strong>Задачі {problem_id}</strong>
                    </div>
                </div>'''

    def _on_generate_final(self, button):
        """Обробник генерації фінальної подачі"""
        # Знаходимо задачі з завантаженими файлами
        submitted_problems = []
        skipped_problems = []
        for problem_id in [p['id'] for p in self.problems]:
            if self.final_codes[problem_id].strip():
                submitted_problems.append(problem_id)
            else:
                skipped_problems.append(problem_id)

        if not submitted_problems:
            error_msg = "❌ Не завантажено жодного файлу. Завантажте принаймні одне рішення."
            self.final_status.value = f'<div style="color: #ef4444; font-size: 14px; margin: 8px 0; padding: 8px; background: #fef2f2; border-radius: 4px;">{error_msg}</div>'
            return

        # Показати стан "подача в обробці"
        self.final_output.clear_output(wait=True)
        with self.final_output:
            display(HTML(get_pending_submission_html()))

        # Тестування поданих рішень
        results = {}
        for problem_id in submitted_problems:
            language = self.final_languages[problem_id].value
            code = self.final_codes[problem_id]

            try:
                result = judge.test_solution_with_public_blocks(problem_id, language, code, self.contest_path)

                if hasattr(result, 'to_dict_clean'):
                    results[problem_id] = result.to_dict_clean()
                elif hasattr(result, 'to_dict'):
                    results[problem_id] = result.to_dict()
                else:
                    results[problem_id] = result

            except Exception as e:
                results[problem_id] = {
                    'verdict': 'ERROR',
                    'passed_tests': 0,
                    'total_tests': 0,
                    'total_time': 0.0,
                    'compile_error': str(e)
                }

        # Створення ZIP файлу
        self._create_final_zip(results, submitted_problems)

    def _create_final_zip(self, test_results, submitted_problems):
        """Створення ZIP файлу з фінальними подачами"""
        import tempfile

        # Створення тимчасового ZIP файлу
        zip_filename = f"final_submission_{time.time_ns()}.zip"

        try:
            with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
                # Додавання файлів з рішеннями (тільки подані задачі)
                for problem_id in submitted_problems:
                    filename = self.final_filenames[problem_id]
                    code = self.final_codes[problem_id]
                    language = self.final_languages[problem_id].value

                    # Визначення розширення файлу з конфігурації
                    extensions = judge.get_language_extensions()

                    # Використання оригінальної назви файлу або створення нової
                    if filename:
                        final_filename = f"{problem_id}_{filename}"
                    else:
                        ext = extensions.get(language, '.txt')
                        final_filename = f"{problem_id}_solution{ext}"

                    # Додавання коду до ZIP
                    zipf.writestr(final_filename, code)

                # Додавання звіту з результатами тестування
                report = self._generate_final_report(test_results)
                zipf.writestr('final_test_results.json', json.dumps(report, ensure_ascii=False, indent=2))

            # Показати результат
            self._show_final_results(zip_filename, test_results)

        except Exception as e:
            print(f"❌ Помилка створення ZIP файлу: {e}")
            self.final_status.value = f'<div style="color: #ef4444; font-size: 14px; margin: 8px 0; padding: 8px; background: #fef2f2; border-radius: 4px;">❌ Помилка створення ZIP: {e}</div>'

    def _generate_final_report(self, test_results):
        """Генерація звіту з результатами фінальної подачі"""
        report = {
            'unix': time.time_ns(),
            'contest_name': self.contest_info.get('name', 'Змагання з програмування'),
            'total_problems': len(self.problems),
            'submitted_problems': len(test_results),
            'problems': {}
        }

        total_passed = 0
        total_tests = 0

        for problem_id, result in test_results.items():
            problem_info = next((p for p in self.problems if p['id'] == problem_id), {})

            # Створюємо очищену версію результату без детальних результатів тестів
            clean_result = {key: value for key, value in result.items() if key != 'test_results'}

            # Також видаляємо блоки з детальними результатами тестів, якщо є
            if 'blocks' in clean_result:
                clean_blocks = []
                for block in clean_result['blocks']:
                    clean_block = {key: value for key, value in block.items() if key != 'test_results'}
                    clean_blocks.append(clean_block)
                clean_result['blocks'] = clean_blocks

            report['problems'][problem_id] = {
                'name': problem_info.get('name', f'Задача {problem_id}'),
                'language': self.final_languages[problem_id].value,
                'filename': self.final_filenames[problem_id],
                'result': clean_result
            }

            total_passed += result.get('passed_tests', 0)
            total_tests += result.get('total_tests', 0)

        report['total_passed'] = total_passed
        report['total_tests'] = total_tests
        report['overall_score'] = f"{total_passed}/{total_tests}"

        return report

    def _show_final_results(self, zip_filename, test_results):
        """Відображення результатів фінальної подачі"""
        # Підрахунок загальної статистики
        total_passed = sum(r.get('passed_tests', 0) for r in test_results.values())
        total_score = sum(r.get('total_score', 0) for r in test_results.values())

        # Підрахунок загальної кількості тестів для ВСІХ задач (включно з пропущеними)
        total_tests = 0
        for problem in self.problems:
            problem_id = problem['id']
            if problem_id in test_results:
                total_tests += test_results[problem_id].get('total_tests', 0)
            else:
                total_tests += self._get_problem_test_count(problem_id)

        # Розрахунок максимально можливого балу для ВСІХ задач (включно з пропущеними)
        max_total_score = 0
        for problem in self.problems:
            problem_id = problem['id']
            if problem_id in test_results:
                # Якщо задачу подано - використовуємо її максимальний бал
                max_total_score += test_results[problem_id].get('max_total_score', 0)
            else:
                # Якщо задачу не подано - читаємо максимальний бал з конфігурації
                max_total_score += self._get_problem_max_score(problem_id)

        # Створення HTML звіту
        score_summary = f" • {total_score}/{max_total_score} балів" if max_total_score > 0 else ""
        html_report = f'''
        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin: 16px 0; color: #1f2937;">
            <h3 style="color: #1e40af; margin: 0 0 16px 0;">🎯 Фінальна подача згенерована!</h3>

            <div style="background: white; border-radius: 6px; padding: 12px; margin: 8px 0;">
                <strong style="color: #1f2937;">📊 Загальний результат: {total_passed}/{total_tests} тестів пройдено{score_summary}</strong>
            </div>

            <div style="margin: 12px 0;">
                <h4 style="color: #374151; margin: 8px 0;">📋 Результати по задачах:</h4>
        '''

        for problem_id, result in test_results.items():
            problem_info = next((p for p in self.problems if p['id'] == problem_id), {})
            verdict = result.get('verdict', 'UNKNOWN')
            passed = result.get('passed_tests', 0)
            total = result.get('total_tests', 0)
            total_score = result.get('total_score', 0)
            max_total_score = result.get('max_total_score', 0)
            language = self.final_languages[problem_id].value

            # Кольори для вердиктів
            colors = {
                'AC': '#10b981',
                'WA': '#ef4444',
                'TLE': '#f59e0b',
                'ERROR': '#8b5cf6',
                'CE': '#f97316'
            }
            color = colors.get(verdict, '#6b7280')

            # Показуємо бали якщо є блокова система
            score_info = f" • {total_score}/{max_total_score} балів" if max_total_score > 0 else ""

            html_report += f'''
                <div style="background: white; border-left: 4px solid {color}; padding: 8px 12px; margin: 4px 0; color: #1f2937;">
                    <strong style="color: #1f2937;">{problem_id}</strong>: {problem_info.get('name', '')} • <span style="color: {color}">{get_verdict_translation(verdict)}</span> • {passed}/{total} тестів{score_info} • {language}
                </div>
            '''

        zip_size = os.path.getsize(zip_filename) / 1024  # KB

        html_report += f'''
            </div>

            <div style="background: #ecfdf5; border: 1px solid #10b981; border-radius: 6px; padding: 12px; margin: 16px 0; color: #065f46;">
                <strong style="color: #065f46;">📦 ZIP архів створено:</strong><br>
                <span style="color: #059669;">📄 Файл: <code style="background: #f0fdf4; color: #047857; padding: 2px 4px; border-radius: 3px;">{zip_filename}</code><br>
                📊 Розмір: {zip_size:.1f} KB</span>
            </div>

            <div style="color: #6b7280; font-size: 12px; margin: 8px 0;">
                💡 Завантажте ZIP файл з поточної директорії для подачі результатів змагання
            </div>
        </div>
        '''

        # Відображення результату
        self.final_output.clear_output()
        with self.final_output:
            display(HTML(html_report))

        # Зберегти ім'я ZIP файлу та показати кнопки завантаження
        self.current_zip_filename = zip_filename
        self.download_zip_button.layout.visibility = 'visible'
        self.download_zip_button_after.layout.visibility = 'visible'

        # ZIP архів готовий - статус очищено для чистого інтерфейсу
        self.final_status.value = ""

    def display(self):
        """Відображення повного інтерфейсу"""
        # Ініціалізація
        self._update_submission_info()

        # Створення єдиної білої картки, що містить усе: задачу, завантаження та результати
        # Контент задачі (без картки, картка буде на рівні контейнера)
        self.problem_content_html = widgets.HTML()

        # Базові елементи (без попереднього перегляду коду)
        self.base_content = [
            # Опис задачі
            self.problem_content_html,

            # Віджети для завантаження тестів (з'являються після завантаження задачі)
            self.test_download_container,

            # Розділювач та заголовок секції завантаження рішення (після тестів)
            widgets.HTML('''
                <div style="border-top: 1px solid #e5e7eb; margin: 32px 0;"></div>
                <h3 style="color:#1f2937;font-size:20px;font-weight:600;margin:0 0 16px 0;display:flex;align-items:center;">
                    <span style="background:#10b981;width:4px;height:20px;border-radius:2px;margin-right:10px;"></span>
                    Завантаження рішення
                </h3>
            '''),

            # Секція вибору мови
            widgets.HTML('<div style="font-weight: 600; color: #374151; font-size: 14px; margin: 8px 0 6px 0; border: none;">🔧 Мова програмування</div>'),
            self.language_selector,

            # Секція завантаження файлу (нижче від мови)
            widgets.HTML('<div style="font-weight: 600; color: #374151; font-size: 14px; margin: 16px 0 6px 0; border: none;">📂 Завантажити файл</div>'),
            self.file_upload,

            # Статус завантаження
            self.submission_info,
        ]

        # Елементи що показуються після завантаження коду
        self.after_upload_content = [
            # Кнопки з покращеним стилем
            widgets.HBox([self.test_button, self.clear_button],
                        layout=widgets.Layout(justify_content='flex-start', margin='20px 0 8px 0')),

            # Розділювач та заголовок результатів
            widgets.HTML(get_unified_card_middle_section()),

            # Результати
            self.results_output,
        ]

        # Створюємо VBox з базовим контентом (без попереднього перегляду)
        self.content_vbox = widgets.VBox(self.base_content + self.after_upload_content)

        # Додаємо CSS клас для білого card стилю
        self.content_vbox.add_class('problem-card')

        # Основний контент для режиму задач з покращеним CSS
        self.problem_content = widgets.VBox([
            # CSS стилі для білої картки з видаленням чорних ліній
            widgets.HTML('''<style>
                .problem-card {
                    background: white;
                    border: 1px solid #e5e7eb;
                    border-radius: 12px;
                    padding: 24px;
                    margin: 16px 0;
                    box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
                }

                /* Видалити всі чорні рамки з віджетів */
                .problem-card * {
                    border-color: #e5e7eb !important;
                }

                /* Повністю видалити чорні лінії з dropdown контейнера */
                .problem-card .widget-dropdown {
                    border: none !important;
                    outline: none !important;
                    box-shadow: none !important;
                }

                /* Стиль для dropdown */
                .problem-card .widget-dropdown select {
                    background: #f9fafb !important;
                    border: 1px solid #d1d5db !important;
                    border-radius: 6px;
                    padding: 8px 12px;
                    font-size: 14px;
                    color: #374151 !important;
                    font-weight: 500;
                    transition: all 0.2s ease;
                    outline: none !important;
                    box-shadow: none !important;
                }
                .problem-card .widget-dropdown select:focus {
                    border-color: #3b82f6 !important;
                    background: #ffffff !important;
                    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1) !important;
                    outline: none !important;
                }

                /* Видалити чорні лінії з усіх VBox та HBox контейнерів */
                .problem-card .widget-vbox,
                .problem-card .widget-hbox {
                    border: none !important;
                    outline: none !important;
                    box-shadow: none !important;
                    background: transparent !important;
                }

                /* Специфічно таргетувати HBox з language selector */
                .problem-card .widget-hbox .widget-dropdown,
                .problem-card .widget-hbox .widget-upload {
                    border: none !important;
                    margin: 0 !important;
                    padding: 0 !important;
                }

                /* Видалити можливі роздільники та лінії між елементами */
                .problem-card .widget-dropdown + *,
                .problem-card .widget-dropdown::after,
                .problem-card .widget-hbox > *:not(:last-child)::after {
                    border: none !important;
                    background: none !important;
                    content: none !important;
                }

                /* Видалити всі можливі псевдо-елементи що можуть створювати лінії */
                .problem-card .widget-dropdown + .widget-upload::before {
                    display: none !important;
                }

                /* Стиль для file upload - видалити всі рамки */
                .problem-card .widget-upload {
                    background: #f8fafc !important;
                    border: 2px dashed #cbd5e0 !important;
                    border-radius: 8px;
                    padding: 16px 12px;
                    text-align: center;
                    transition: all 0.2s ease;
                    cursor: pointer;
                }
                .problem-card .widget-upload:hover {
                    border-color: #3b82f6 !important;
                    background: #eff6ff !important;
                }
                .problem-card .widget-upload input[type="file"] {
                    color: #374151 !important;
                    font-weight: 500;
                    font-size: 14px;
                    border: none !important;
                    background: transparent !important;
                }
                .problem-card .widget-upload button {
                    background: #3b82f6 !important;
                    color: white !important;
                    border: none !important;
                    border-radius: 6px;
                    padding: 8px 16px;
                    font-weight: 600;
                    font-size: 14px;
                    cursor: pointer;
                    transition: all 0.2s ease;
                }

                /* Виправити білий текст в file upload - агресивне таргетування */
                .problem-card .widget-upload,
                .problem-card .widget-upload *,
                .problem-card .widget-upload input,
                .problem-card .widget-upload label,
                .problem-card .widget-upload span,
                .problem-card .widget-upload div,
                .problem-card .widget-upload p {
                    color: #374151 !important;
                    font-weight: 500 !important;
                }

                /* Спеціально для кнопки вибору файлу */
                .problem-card .widget-upload input[type="file"]::-webkit-file-upload-button {
                    color: #374151 !important;
                    background: #f3f4f6 !important;
                    border: 1px solid #d1d5db !important;
                    border-radius: 4px;
                    padding: 6px 12px;
                    font-size: 14px;
                    font-weight: 500;
                }

                /* Для браузерів що не підтримують webkit */
                .problem-card .widget-upload input[type="file"]::file-selector-button {
                    color: #374151 !important;
                    background: #f3f4f6 !important;
                    border: 1px solid #d1d5db !important;
                    border-radius: 4px;
                    padding: 6px 12px;
                    font-size: 14px;
                    font-weight: 500;
                }

                /* Стиль для кнопок - видалити чорні рамки */
                .problem-card .widget-button {
                    border-radius: 6px !important;
                    font-weight: 600;
                    transition: all 0.2s ease;
                    border: none !important;
                }

                /* Стиль для textarea - видалити чорні рамки */
                .problem-card .widget-textarea textarea {
                    background: #f8fafc !important;
                    border: 1px solid #d1d5db !important;
                    border-radius: 8px;
                    padding: 12px;
                    font-family: 'Monaco', 'Consolas', 'Liberation Mono', 'Courier New', monospace;
                    font-size: 13px;
                    line-height: 1.5;
                    transition: border-color 0.2s ease;
                    outline: none !important;
                    color: #374151 !important;
                }
                .problem-card .widget-textarea textarea:focus {
                    border-color: #3b82f6 !important;
                    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1) !important;
                }

                /* Видалити чорні лінії з HTML елементів */
                .problem-card div {
                    border: none !important;
                }

                /* Агресивно видалити всі можливі чорні лінії */
                .problem-card *,
                .problem-card *::before,
                .problem-card *::after {
                    border: none !important;
                    outline: none !important;
                    box-shadow: none !important;
                }

                /* Виключення - відновити потрібні стилі */
                .problem-card .widget-dropdown select {
                    border: 1px solid #d1d5db !important;
                }
                .problem-card .widget-dropdown select:focus {
                    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1) !important;
                }
                .problem-card .widget-upload {
                    border: 2px dashed #cbd5e0 !important;
                }
                .problem-card .widget-textarea textarea {
                    border: 1px solid #d1d5db !important;
                }
                .problem-card .widget-textarea textarea:focus {
                    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1) !important;
                }
                .problem-card {
                    border: 1px solid #e5e7eb !important;
                    box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1) !important;
                }
            </style>'''),
            self.content_vbox
        ])

        # Динамічний контейнер для контенту
        self.content_area = widgets.VBox([self.problem_content])

        # Створення головного інтерфейсу
        interface = widgets.VBox([
            self.header,
            widgets.HTML(get_section_header('Навігація')),
            self.problem_nav,
            self.content_area
        ])

        # Відображення
        display(interface)

        # Ініціалізувати функціонал завантаження
        self._setup_download_functionality()

        self._show_problem(self.current_problem)