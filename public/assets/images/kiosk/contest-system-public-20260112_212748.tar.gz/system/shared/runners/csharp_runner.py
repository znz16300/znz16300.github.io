#!/usr/bin/env python3
"""
C# language runner for competitive programming judge
"""

import os
import subprocess
import sys
import shutil
import time
from typing import Tuple


def detect_csharp_environment():
    """Detect the current environment for C# installation"""

    # Check for Google Colab
    colab_indicators = [
        'COLAB_GPU' in os.environ,
        os.path.exists('/content'),
        'google.colab' in str(sys.modules.keys()),
    ]

    if any(colab_indicators):
        return "colab"

    # Check for common Linux distributions
    if os.path.exists('/etc/os-release'):
        try:
            with open('/etc/os-release', 'r') as f:
                content = f.read().lower()
                if 'ubuntu' in content or 'debian' in content:
                    return "ubuntu"
                elif 'fedora' in content:
                    return "fedora"
                elif 'centos' in content or 'rhel' in content:
                    return "centos"
        except:
            pass

    # Check for macOS
    if sys.platform == "darwin":
        return "macos"

    # Check for Windows
    if sys.platform == "win32":
        return "windows"

    return "unknown"


def install_dotnet():
    """Install .NET SDK automatically"""

    # First check if already installed and working
    if shutil.which('dotnet'):
        # Test if .NET is actually functional
        try:
            result = subprocess.run(['dotnet', '--version'],
                                  capture_output=True, timeout=10, text=True)
            if result.returncode == 0:
                print("✅ .NET SDK is already installed and working!")
                return True, ".NET SDK found and functional"
        except:
            pass

    env = detect_csharp_environment()
    print(f"🔍 .NET SDK not working properly. Environment: {env}")

    try:
        if env == "colab":
            print("🔧 Installing .NET SDK in Google Colab...")

            # Try snap installation first (often more reliable in Colab)
            print("🔨 Trying snap installation...")
            result = subprocess.run(['snap', 'install', 'dotnet-sdk', '--classic'],
                                  capture_output=True, timeout=300)

            if result.returncode == 0:
                # Add snap bin to PATH if not already there
                snap_path = '/snap/bin'
                if snap_path not in os.environ.get('PATH', ''):
                    os.environ['PATH'] = f"{snap_path}:{os.environ.get('PATH', '')}"

                # Test snap installation
                if shutil.which('dotnet') or os.path.exists('/snap/bin/dotnet'):
                    try:
                        dotnet_cmd = shutil.which('dotnet') or '/snap/bin/dotnet'
                        test_result = subprocess.run([dotnet_cmd, '--version'],
                                                   capture_output=True, timeout=10, text=True)
                        if test_result.returncode == 0:
                            print("✅ .NET SDK installed successfully via snap!")
                            return True, ".NET SDK installed successfully via snap"
                    except:
                        pass

            # Fall back to apt installation
            print("📦 Trying apt installation as fallback...")

            # Download and install Microsoft package repository
            result = subprocess.run([
                'wget', 'https://packages.microsoft.com/config/ubuntu/20.04/packages-microsoft-prod.deb',
                '-O', '/tmp/packages-microsoft-prod.deb'
            ], capture_output=True, timeout=60)

            if result.returncode == 0:
                subprocess.run(['dpkg', '-i', '/tmp/packages-microsoft-prod.deb'],
                              capture_output=True, timeout=30)

            # Update package list
            result = subprocess.run(['apt', 'update', '-qq'],
                                  capture_output=True, timeout=60)

            # Install .NET SDK
            result = subprocess.run(['apt', 'install', '-y', 'dotnet-sdk-6.0'],
                                  capture_output=True, timeout=300)

            if result.returncode == 0:
                # Verify installation with better testing
                if shutil.which('dotnet'):
                    try:
                        test_result = subprocess.run(['dotnet', '--version'],
                                                   capture_output=True, timeout=10, text=True)
                        if test_result.returncode == 0:
                            print("✅ .NET SDK installed successfully via apt!")
                            return True, ".NET SDK installed successfully via apt"
                        else:
                            print("⚠️ .NET SDK installed but not functional via apt")
                    except:
                        print("⚠️ .NET SDK installed but version check failed")

            error_msg = result.stderr.decode() if result.stderr else "Installation failed"
            print(f"❌ Both snap and apt .NET SDK installations failed")
            return False, f"Auto-installation failed: {error_msg}"

        elif env == "ubuntu":
            # Try automatic installation for Ubuntu/Debian
            print("🐧 Ubuntu/Debian detected - attempting automatic installation...")

            try:
                # Try to install without sudo first (if running as root)
                if os.geteuid() == 0:
                    print("🔧 Installing as root...")

                    # Add Microsoft repository
                    result = subprocess.run([
                        'wget', 'https://packages.microsoft.com/config/ubuntu/20.04/packages-microsoft-prod.deb',
                        '-O', '/tmp/packages-microsoft-prod.deb'
                    ], capture_output=True, timeout=60)

                    if result.returncode == 0:
                        subprocess.run(['dpkg', '-i', '/tmp/packages-microsoft-prod.deb'],
                                      capture_output=True, timeout=30)

                    result = subprocess.run(['apt', 'update', '-qq'], capture_output=True, timeout=60)
                    result = subprocess.run(['apt', 'install', '-y', 'dotnet-sdk-6.0'],
                                          capture_output=True, timeout=300)

                    if result.returncode == 0 and shutil.which('dotnet'):
                        print("✅ .NET SDK installed successfully!")
                        return True, ".NET SDK installed successfully"

                # Fall back to manual instructions
                return False, """.NET SDK not found.
Please install it with:
  wget https://packages.microsoft.com/config/ubuntu/20.04/packages-microsoft-prod.deb -O packages-microsoft-prod.deb
  sudo dpkg -i packages-microsoft-prod.deb
  sudo apt update
  sudo apt install -y dotnet-sdk-6.0
Then restart your Python kernel."""

            except Exception as e:
                return False, f".NET SDK installation attempt failed: {str(e)}"

        elif env == "fedora":
            return False, """.NET SDK not found.
Please install it with: sudo dnf install dotnet-sdk-6.0
Then restart your Python kernel."""

        elif env == "centos":
            return False, """.NET SDK not found.
Please install it with: sudo yum install dotnet-sdk-6.0
Then restart your Python kernel."""

        elif env == "macos":
            return False, """.NET SDK not found.
Please install it with: brew install --cask dotnet-sdk
Or download from: https://dotnet.microsoft.com/download
Then restart your Python kernel."""

        elif env == "windows":
            return False, """.NET SDK not found.
Download installer from: https://dotnet.microsoft.com/download
Choose '.NET SDK' and follow the setup wizard
Then restart your Python kernel."""

        else:
            return False, """.NET SDK not found.
Download from: https://dotnet.microsoft.com/download
Then restart your Python kernel."""

    except subprocess.TimeoutExpired:
        return False, ".NET SDK installation timed out"
    except Exception as e:
        print(f"❌ Error during .NET SDK installation: {e}")
        return False, f"Error during .NET SDK installation: {str(e)}"


def install_mono():
    """Install Mono as fallback for C# compilation"""

    # Check if already installed
    if shutil.which('mcs') and shutil.which('mono'):
        print("✅ Mono is already installed!")
        return True, "Mono found"

    env = detect_csharp_environment()
    print(f"🔍 Mono not found. Environment: {env}")

    try:
        if env == "colab":
            print("🔧 Installing Mono in Google Colab...")

            # Update package list
            print("📦 Updating package list...")
            result = subprocess.run(['apt', 'update', '-qq'],
                                  capture_output=True, timeout=60)

            # Install Mono
            print("🔨 Installing Mono...")
            result = subprocess.run(['apt', 'install', '-y', 'mono-devel'],
                                  capture_output=True, timeout=180)

            if result.returncode == 0:
                print("✅ Mono installation completed!")

                # Verify installation
                if shutil.which('mcs') and shutil.which('mono'):
                    print("🎉 Mono is now available!")
                    return True, "Mono installed successfully in Google Colab"
                else:
                    return False, "Mono installation completed but commands not found in PATH"
            else:
                error_msg = result.stderr.decode() if result.stderr else "Installation failed"
                print(f"❌ Mono installation failed: {error_msg}")
                return False, f"Mono auto-installation failed: {error_msg}"

        elif env == "ubuntu":
            # Try automatic installation for Ubuntu/Debian
            print("🐧 Ubuntu/Debian detected - attempting Mono installation...")

            try:
                if os.geteuid() == 0:
                    print("🔧 Installing Mono as root...")
                    result = subprocess.run(['apt', 'update', '-qq'], capture_output=True, timeout=60)
                    result = subprocess.run(['apt', 'install', '-y', 'mono-devel'],
                                          capture_output=True, timeout=180)

                    if result.returncode == 0 and shutil.which('mcs'):
                        print("✅ Mono installed successfully!")
                        return True, "Mono installed successfully"

                # Fall back to manual instructions
                return False, """Mono not found.
Please install it with: sudo apt update && sudo apt install mono-devel
Then restart your Python kernel."""

            except Exception as e:
                return False, f"Mono installation attempt failed: {str(e)}"

        elif env == "macos":
            return False, """Mono not found.
Please install it with: brew install mono
Then restart your Python kernel."""

        else:
            return False, """Mono not found.
Please install it from: https://www.mono-project.com/download/
Then restart your Python kernel."""

    except subprocess.TimeoutExpired:
        return False, "Mono installation timed out"
    except Exception as e:
        print(f"❌ Error during Mono installation: {e}")
        return False, f"Error during Mono installation: {str(e)}"


def test_csharp_installation():
    """Test C# compiler after installation"""
    print("🧪 Testing C# compiler...")

    # Create a simple test program
    test_code = '''using System;
class Hello {
    static void Main() {
        Console.WriteLine("Hello, C#!");
    }
}'''

    try:
        # Use temp directory for testing
        import tempfile
        with tempfile.TemporaryDirectory() as temp_dir:
            test_file = os.path.join(temp_dir, 'test.cs')
            test_exe = os.path.join(temp_dir, 'test.exe')

            # Write test file
            with open(test_file, 'w') as f:
                f.write(test_code)

            # Try .NET first
            if shutil.which('dotnet'):
                try:
                    result = subprocess.run(['dotnet', 'new', 'console', '--force'],
                                          cwd=temp_dir, capture_output=True, timeout=10)
                    with open(os.path.join(temp_dir, 'Program.cs'), 'w') as f:
                        f.write(test_code)

                    result = subprocess.run(['dotnet', 'build'],
                                          cwd=temp_dir, capture_output=True, timeout=10)

                    if result.returncode == 0:
                        result = subprocess.run(['dotnet', 'run'],
                                              cwd=temp_dir, capture_output=True, timeout=5, text=True)
                        if result.returncode == 0:
                            print(f"✅ .NET test successful! Output: {result.stdout.strip()}")
                            return True, ".NET compiler working correctly"
                except Exception:
                    pass

            # Try Mono as fallback
            if shutil.which('mcs') and shutil.which('mono'):
                try:
                    result = subprocess.run(['mcs', '-out:' + test_exe, test_file],
                                          capture_output=True, timeout=10)

                    if result.returncode == 0:
                        result = subprocess.run(['mono', test_exe],
                                              capture_output=True, timeout=5, text=True)
                        if result.returncode == 0:
                            print(f"✅ Mono test successful! Output: {result.stdout.strip()}")
                            return True, "Mono compiler working correctly"
                except Exception:
                    pass

            return False, "C# compilation test failed"

    except Exception as e:
        return False, f"C# test failed: {str(e)}"


def check_csharp_compiler():
    """Check if C# compiler is available and try to install if missing"""

    # First check if we have functional .NET SDK
    if shutil.which('dotnet'):
        try:
            result = subprocess.run(['dotnet', '--version'],
                                  capture_output=True, timeout=10, text=True)
            if result.returncode == 0:
                return True, ".NET SDK found and functional"
        except:
            pass

    # Check if Mono is available
    if shutil.which('mcs') and shutil.which('mono'):
        return True, "Mono found and ready"

    print("🔍 No working C# compiler found. Attempting to install...")

    # In Google Colab, try Mono first as it's more reliable
    env = detect_csharp_environment()
    if env == "colab":
        print("💡 In Google Colab: trying Mono first...")
        success, message = install_mono()
        if success:
            # Test the installation
            test_success, test_message = test_csharp_installation()
            if test_success:
                return True, "Mono installed and tested successfully"

        # If Mono fails, try .NET SDK
        print("💡 Mono failed, trying .NET SDK...")
        success, message = install_dotnet()
        if success:
            # Test the installation
            test_success, test_message = test_csharp_installation()
            if test_success:
                return True, ".NET SDK installed and tested successfully"
            else:
                return True, f".NET SDK installed but test failed: {test_message}"
    else:
        # For other environments, try .NET SDK first
        success, message = install_dotnet()
        if success:
            # Test the installation
            test_success, test_message = test_csharp_installation()
            if test_success:
                return True, ".NET SDK installed and tested successfully"
            else:
                return True, f".NET SDK installed but test failed: {test_message}"

        # If .NET SDK fails, try Mono
        print("💡 .NET SDK installation failed, trying Mono...")
        success, message = install_mono()
        if success:
            # Test the installation
            test_success, test_message = test_csharp_installation()
            if test_success:
                return True, "Mono installed and tested successfully"
            else:
                return True, f"Mono installed but test failed: {test_message}"

    return False, "Could not install .NET SDK or Mono. " + message


def get_language_info():
    """Get C# language configuration"""
    available, message = check_csharp_compiler()

    return {
        'name': 'C#',
        'source_ext': '.cs',
        'executable_ext': '.exe',
        'time_multiplier': 2.0,
        'compile_timeout': 15,
        'needs_compilation': True,
        'available': available,
        'status_message': message
    }


def compile_code(source_file: str, temp_dir: str) -> Tuple[bool, str]:
    """
    Compile C# code

    Returns:
        Tuple[bool, str]: (success, error_message)
    """
    # Check if compiler is available and try to install if needed
    available, status_message = check_csharp_compiler()
    if not available:
        return False, f"❌ {status_message}"

    executable_file = os.path.join(temp_dir, 'solution.exe')

    try:
        # Try .NET SDK first
        if shutil.which('dotnet'):
            try:
                # Test if dotnet is functional
                test_result = subprocess.run(['dotnet', '--version'],
                                           capture_output=True, timeout=5, text=True)

                if test_result.returncode == 0:
                    # Initialize dotnet project
                    init_result = subprocess.run(
                        ['dotnet', 'new', 'console', '--force'],
                        capture_output=True,
                        timeout=15,
                        text=True,
                        cwd=temp_dir
                    )

                    if init_result.returncode == 0:
                        # Copy our source to Program.cs
                        import shutil as sh
                        sh.copy2(source_file, os.path.join(temp_dir, 'Program.cs'))

                        # Build the project
                        compile_result = subprocess.run(
                            ['dotnet', 'build', '--configuration', 'Release'],
                            capture_output=True,
                            timeout=30,
                            text=True,
                            cwd=temp_dir
                        )

                        if compile_result.returncode == 0:
                            return True, ""
                        else:
                            # .NET compilation failed, try Mono as fallback
                            print("⚠️ .NET compilation failed, trying Mono...")
                    else:
                        # .NET project initialization failed, try Mono as fallback
                        print("⚠️ .NET project initialization failed, trying Mono...")
                        print(f"Error: {init_result.stderr}")
                else:
                    print("⚠️ .NET SDK not functional, trying Mono...")
            except Exception as e:
                print(f"⚠️ .NET SDK error: {e}, trying Mono...")

        # Use Mono as fallback or primary option
        if shutil.which('mcs') and shutil.which('mono'):
            compile_result = subprocess.run(
                ['mcs', '-out:' + executable_file, source_file],
                capture_output=True,
                timeout=30,
                text=True,
                cwd=temp_dir
            )

            if compile_result.returncode == 0:
                return True, ""
            else:
                # Clean error message
                error_msg = compile_result.stderr.strip()
                if not error_msg and compile_result.stdout:
                    error_msg = compile_result.stdout.strip()
                if not error_msg:
                    error_msg = f"Mono compilation failed with exit code {compile_result.returncode}"
                return False, error_msg
        else:
            return False, "No working C# compiler found (.NET SDK and Mono both unavailable)"

    except subprocess.TimeoutExpired:
        return False, "C# compilation timed out after 30 seconds"
    except Exception as e:
        return False, f"C# compilation error: {str(e)}"


def run_code(source_file: str, input_data: str, time_limit: float, temp_dir: str) -> Tuple[str, str]:
    """
    Execute C# code with given input

    Args:
        source_file: Path to source file
        input_data: Input data to pass to program
        time_limit: Maximum execution time in seconds
        temp_dir: Temporary directory for execution

    Returns:
        Tuple[str, str]: (verdict, output/error_message)
        Verdicts: 'AC' (Accepted), 'TLE' (Time Limit Exceeded), 'RE' (Runtime Error)
    """
    executable_file = os.path.join(temp_dir, 'solution.exe')

    try:
        start_time = time.time()

        # Determine which runtime to use based on what's available and what was compiled
        # Check if we have a .NET project (has .csproj files)
        has_dotnet_project = any(f.endswith('.csproj') for f in os.listdir(temp_dir))

        if has_dotnet_project and shutil.which('dotnet'):
            try:
                # Test if .NET runtime is functional
                test_result = subprocess.run(['dotnet', '--version'],
                                           capture_output=True, timeout=5, text=True)

                if test_result.returncode == 0:
                    # For .NET projects, we use 'dotnet run'
                    result = subprocess.run(
                        ['dotnet', 'run', '--configuration', 'Release'],
                        input=input_data,
                        capture_output=True,
                        timeout=time_limit,
                        text=True,
                        cwd=temp_dir
                    )
                else:
                    raise Exception(".NET runtime not functional")
            except Exception:
                # .NET failed, fall back to Mono if executable exists
                if shutil.which('mono') and os.path.exists(executable_file):
                    result = subprocess.run(
                        ['mono', executable_file],
                        input=input_data,
                        capture_output=True,
                        timeout=time_limit,
                        text=True,
                        cwd=temp_dir
                    )
                else:
                    return 'RE', ".NET runtime failed and no Mono executable available"

        elif shutil.which('mono') and os.path.exists(executable_file):
            # For Mono, run the executable with mono
            result = subprocess.run(
                ['mono', executable_file],
                input=input_data,
                capture_output=True,
                timeout=time_limit,
                text=True,
                cwd=temp_dir
            )
        else:
            return 'RE', "No C# runtime found or executable missing"

        execution_time = time.time() - start_time

        # Check for runtime errors (non-zero exit code)
        if result.returncode != 0:
            error_msg = result.stderr.strip() or "Runtime error (non-zero exit code)"
            return 'RE', error_msg

        # Success case
        return 'AC', result.stdout.strip()

    except subprocess.TimeoutExpired:
        return 'TLE', ''
    except Exception as e:
        return 'RE', str(e)


def prepare_source_file(code: str, temp_dir: str) -> str:
    """
    Prepare C# source file

    Args:
        code: Source code
        temp_dir: Temporary directory

    Returns:
        str: Path to prepared source file
    """
    source_file = os.path.join(temp_dir, 'solution.cs')

    try:
        with open(source_file, 'w', encoding='utf-8') as f:
            f.write(code)
        return source_file
    except Exception as e:
        raise RuntimeError(f"Failed to write C# source file: {e}")


def get_template_code() -> str:
    """Get template code for C#"""
    return '''using System;

class Program
{
    static void Main()
    {
        // Your C# solution here

        // Read input
        int n = int.Parse(Console.ReadLine());

        // Process and output result
        Console.WriteLine(n);
    }
}'''


def cleanup(temp_dir: str):
    """
    Clean up temporary files after execution

    Args:
        temp_dir: Directory to clean up
    """
    # Clean up executable and any compilation artifacts
    files_to_remove = [
        'solution.exe', 'solution.dll', 'solution.pdb',
        'obj', 'bin', 'Program.cs',
        '*.csproj', '*.sln'
    ]

    for filename in files_to_remove:
        file_path = os.path.join(temp_dir, filename)
        if os.path.exists(file_path):
            try:
                if os.path.isdir(file_path):
                    import shutil
                    shutil.rmtree(file_path)
                else:
                    os.remove(file_path)
            except:
                pass  # Ignore cleanup errors

    # Also clean up .csproj files (they may have random names)
    try:
        import glob
        for csproj in glob.glob(os.path.join(temp_dir, "*.csproj")):
            try:
                os.remove(csproj)
            except:
                pass
    except:
        pass