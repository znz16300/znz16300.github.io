#!/usr/bin/env python3
"""
Pascal language runner for competitive programming judge
"""

import os
import subprocess
import sys
import time
import shutil
from typing import Tuple


def detect_environment():
    """Detect the current environment for Pascal installation"""

    # Check for Google Colab
    colab_indicators = [
        'COLAB_GPU' in os.environ,
        os.path.exists('/content'),
        'google.colab' in str(sys.modules.keys()),
    ]

    if any(colab_indicators):
        return "colab"

    # Check for common Linux distributions
    if os.path.exists('/etc/os-release'):
        try:
            with open('/etc/os-release', 'r') as f:
                content = f.read().lower()
                if 'ubuntu' in content or 'debian' in content:
                    return "ubuntu"
                elif 'fedora' in content:
                    return "fedora"
                elif 'centos' in content or 'rhel' in content:
                    return "centos"
        except:
            pass

    # Check for macOS
    if sys.platform == "darwin":
        return "macos"

    # Check for Windows
    if sys.platform == "win32":
        return "windows"

    return "unknown"


def install_pascal_compiler():
    """Install Free Pascal compiler automatically"""

    # First check if already installed
    if shutil.which('fpc'):
        print("✅ Free Pascal compiler is already installed!")
        return True, "Free Pascal compiler found"

    env = detect_environment()
    print(f"🔍 Pascal compiler not found. Environment: {env}")

    try:
        if env == "colab":
            print("🔧 Installing Free Pascal in Google Colab...")

            # Update package list
            print("📦 Updating package list...")
            result = subprocess.run(['apt', 'update', '-qq'],
                                  capture_output=True, timeout=60)
            if result.returncode != 0:
                print("⚠️  Package update failed, continuing anyway...")

            # Install FPC
            print("🔨 Installing Free Pascal compiler...")
            result = subprocess.run(['apt', 'install', '-y', 'fpc'],
                                  capture_output=True, timeout=180)

            if result.returncode == 0:
                print("✅ Installation completed!")

                # Verify installation
                if shutil.which('fpc'):
                    print("🎉 Free Pascal compiler is now available!")
                    try:
                        subprocess.run(['fpc', '-iV'], capture_output=True)
                    except:
                        pass
                    return True, "Free Pascal installed successfully in Google Colab"
                else:
                    return False, "Free Pascal installation completed but fpc not found in PATH"
            else:
                error_msg = result.stderr.decode() if result.stderr else "Installation failed"
                print(f"❌ Installation failed: {error_msg}")
                return False, f"Auto-installation failed: {error_msg}"

        elif env == "ubuntu":
            # Try automatic installation for Ubuntu/Debian
            print("🐧 Ubuntu/Debian detected - attempting automatic installation...")

            try:
                # Try to install without sudo first (if running as root)
                if os.geteuid() == 0:
                    print("🔧 Installing as root...")
                    result = subprocess.run(['apt', 'update', '-qq'], capture_output=True, timeout=60)
                    result = subprocess.run(['apt', 'install', '-y', 'fpc'], capture_output=True, timeout=180)

                    if result.returncode == 0 and shutil.which('fpc'):
                        print("✅ Free Pascal installed successfully!")
                        return True, "Free Pascal installed successfully"

                # Fall back to manual instructions
                return False, """Pascal compiler (fpc) not found.
Please install it with: sudo apt update && sudo apt install fpc
Then restart your Python kernel."""

            except Exception as e:
                return False, f"Installation attempt failed: {str(e)}"

        elif env == "fedora":
            return False, """Pascal compiler (fpc) not found.
Please install it with: sudo dnf install fpc
Then restart your Python kernel."""

        elif env == "centos":
            return False, """Pascal compiler (fpc) not found.
Please install it with: sudo yum install fpc
Then restart your Python kernel."""

        elif env == "macos":
            return False, """Pascal compiler (fpc) not found.
Please install it with: brew install fpc
Or download from: https://www.freepascal.org/download.html
Then restart your Python kernel."""

        elif env == "windows":
            return False, """Pascal compiler (fpc) not found.
Download installer from: https://www.freepascal.org/download.html
Choose 'Windows' and follow the setup wizard
Then restart your Python kernel."""

        else:
            return False, """Pascal compiler (fpc) not found.
Download from: https://www.freepascal.org/download.html
Then restart your Python kernel."""

    except subprocess.TimeoutExpired:
        return False, "Pascal installation timed out"
    except Exception as e:
        print(f"❌ Error during installation: {e}")
        return False, f"Error during Pascal installation: {str(e)}"


def test_pascal_installation():
    """Test Pascal compiler after installation"""
    if not shutil.which('fpc'):
        return False, "Pascal compiler not found after installation"

    print("🧪 Testing Pascal compiler...")

    # Create a simple test program
    test_code = '''program Hello;
begin
    writeln('Hello, Pascal!');
end.'''

    try:
        # Use temp directory for testing
        import tempfile
        with tempfile.TemporaryDirectory() as temp_dir:
            test_file = os.path.join(temp_dir, 'test.pas')
            test_exe = os.path.join(temp_dir, 'test')

            # Write test file
            with open(test_file, 'w') as f:
                f.write(test_code)

            # Compile
            result = subprocess.run(['fpc', '-o' + test_exe, test_file],
                                  capture_output=True, timeout=10)

            if result.returncode == 0:
                print("✅ Pascal compilation test successful!")

                # Run the program
                result = subprocess.run([test_exe],
                                      capture_output=True, timeout=5, text=True)

                if result.returncode == 0:
                    print(f"✅ Pascal execution test successful! Output: {result.stdout.strip()}")
                    return True, "Pascal compiler working correctly"
                else:
                    return False, "Pascal execution test failed"
            else:
                return False, f"Pascal compilation test failed: {result.stderr.decode()}"

    except Exception as e:
        return False, f"Pascal test failed: {str(e)}"


def check_pascal_compiler():
    """Check if Pascal compiler is available and try to install if missing"""

    # First, check if fpc is already available
    if shutil.which('fpc'):
        return True, "Free Pascal compiler found"

    print("🔍 Pascal compiler (fpc) not found. Attempting to install...")

    # Try to install Pascal compiler
    success, message = install_pascal_compiler()

    if success:
        # Test the installation
        test_success, test_message = test_pascal_installation()
        if test_success:
            return True, "Free Pascal compiler installed and tested successfully"
        else:
            return True, f"Free Pascal compiler installed but test failed: {test_message}"

    return False, message


def get_language_info():
    """Get Pascal language configuration"""
    available, message = check_pascal_compiler()

    return {
        'name': 'Pascal',
        'source_ext': '.pas',
        'executable_ext': '',
        'time_multiplier': 1.0,
        'compile_timeout': 10,
        'needs_compilation': True,
        'available': available,
        'status_message': message
    }


def compile_code(source_file: str, temp_dir: str) -> Tuple[bool, str]:
    """
    Compile Pascal code

    Returns:
        Tuple[bool, str]: (success, error_message)
    """
    # Check if compiler is available and try to install if needed
    available, status_message = check_pascal_compiler()
    if not available:
        return False, f"❌ {status_message}"

    executable_file = os.path.join(temp_dir, 'solution')

    try:
        # Use Free Pascal compiler (fpc)
        compile_result = subprocess.run([
            'fpc',
            '-o' + executable_file,
            source_file,
            '-O2',           # Optimization
            '-Xe',           # Allow executable generation
            '-vewnhi'        # Verbose error reporting
        ],
        capture_output=True,
        timeout=30,  # Increased timeout
        text=True,
        cwd=temp_dir
        )

        if compile_result.returncode != 0:
            # Clean error message
            error_msg = compile_result.stderr.strip()
            if not error_msg and compile_result.stdout:
                error_msg = compile_result.stdout.strip()
            if not error_msg:
                error_msg = f"Pascal compilation failed with exit code {compile_result.returncode}"

            return False, error_msg

        # Verify executable was created
        if not os.path.exists(executable_file):
            error_msg = "Compilation appeared successful but executable was not created"
            return False, error_msg

        return True, ""

    except subprocess.TimeoutExpired:
        error_msg = "Pascal compilation timed out after 30 seconds"
        return False, error_msg

    except FileNotFoundError:
        # This shouldn't happen after our check, but just in case
        error_msg = """Pascal compiler (fpc) not found after installation check.
Try restarting your Python kernel and running again."""
        return False, error_msg

    except Exception as e:
        error_msg = f"Pascal compilation error: {str(e)}"
        return False, error_msg


def run_code(source_file: str, input_data: str, time_limit: float, temp_dir: str) -> Tuple[str, str]:
    """
    Execute Pascal code with given input

    Args:
        source_file: Path to source file
        input_data: Input data to pass to program
        time_limit: Maximum execution time in seconds
        temp_dir: Temporary directory for execution

    Returns:
        Tuple[str, str]: (verdict, output/error_message)
        Verdicts: 'AC' (Accepted), 'TLE' (Time Limit Exceeded), 'RE' (Runtime Error)
    """
    executable_file = os.path.join(temp_dir, 'solution')

    try:
        start_time = time.time()
        result = subprocess.run(
            [executable_file],
            input=input_data,
            capture_output=True,
            timeout=time_limit,
            text=True,
            cwd=temp_dir
        )

        execution_time = time.time() - start_time

        # Check for runtime errors (non-zero exit code)
        if result.returncode != 0:
            error_msg = result.stderr.strip() or "Runtime error (non-zero exit code)"
            return 'RE', error_msg

        # Success case
        return 'AC', result.stdout.strip()

    except subprocess.TimeoutExpired:
        return 'TLE', ''

    except Exception as e:
        return 'RE', str(e)


def prepare_source_file(code: str, temp_dir: str) -> str:
    """
    Prepare Pascal source file

    Args:
        code: Source code
        temp_dir: Temporary directory

    Returns:
        str: Path to prepared source file
    """
    source_file = os.path.join(temp_dir, 'solution.pas')

    try:
        with open(source_file, 'w', encoding='utf-8') as f:
            f.write(code)
        return source_file
    except Exception as e:
        raise RuntimeError(f"Failed to write Pascal source file: {e}")


def get_template_code() -> str:
    """Get template code for Pascal"""
    return '''program Solution;
var
    n: integer;
begin
    // Your Pascal solution here

    // Read input
    readln(n);

    // Process and output result
    writeln(n);
end.'''


def cleanup(temp_dir: str):
    """
    Clean up temporary files after execution

    Args:
        temp_dir: Directory to clean up
    """
    # Clean up executable and any compilation artifacts
    files_to_remove = ['solution', 'solution.o', 'solution.ppu']

    for filename in files_to_remove:
        file_path = os.path.join(temp_dir, filename)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
            except:
                pass  # Ignore cleanup errors