#!/usr/bin/env python3
"""
Java language runner for competitive programming judge
"""

import os
import subprocess
import time
import re
from typing import Tuple, Optional


def get_language_info():
    """Get Java language configuration"""
    return {
        'name': 'Java',
        'source_ext': '.java',
        'executable_ext': '.class',
        'time_multiplier': 2.0,
        'compile_timeout': 15,
        'needs_compilation': True
    }


def extract_class_name(source_code: str) -> Optional[str]:
    """Extract the main class name from Java source code"""
    # Look for public class declaration
    match = re.search(r'public\s+class\s+(\w+)', source_code)
    if match:
        return match.group(1)

    # Look for any class declaration
    match = re.search(r'class\s+(\w+)', source_code)
    if match:
        return match.group(1)

    return None


def compile_code(source_file: str, temp_dir: str) -> Tuple[bool, str]:
    """
    Compile Java code

    Returns:
        Tuple[bool, str]: (success, error_message)
    """
    try:
        compile_result = subprocess.run([
            'javac', source_file
        ],
        capture_output=True,
        timeout=15,
        text=True,
        cwd=temp_dir
        )

        if compile_result.returncode != 0:
            return False, compile_result.stderr

        return True, ""

    except subprocess.TimeoutExpired:
        return False, "Compilation timed out after 15 seconds"
    except FileNotFoundError:
        return False, "Java compiler (javac) not found. Please install Java JDK."
    except Exception as e:
        return False, str(e)


def run_code(source_file: str, input_data: str, time_limit: float, temp_dir: str) -> Tuple[str, str]:
    """
    Execute Java code with given input

    Args:
        source_file: Path to Java source file
        input_data: Input data as string
        time_limit: Time limit in seconds (will be multiplied by 2.0)
        temp_dir: Temporary directory path

    Returns:
        Tuple[str, str]: (verdict, output/error_message)
        Verdicts: 'AC' (Accepted), 'TLE' (Time Limit Exceeded), 'RE' (Runtime Error)
    """
    try:
        # Read source file to extract class name
        with open(source_file, 'r') as f:
            source_code = f.read()

        class_name = extract_class_name(source_code) or 'Main'
        adjusted_time_limit = time_limit * 2.0  # Java time multiplier

        start_time = time.time()

        result = subprocess.run([
            'java', '-cp', temp_dir, class_name
        ],
        input=input_data,
        capture_output=True,
        timeout=adjusted_time_limit,
        text=True,
        cwd=temp_dir
        )

        execution_time = time.time() - start_time

        if result.returncode != 0:
            return 'RE', result.stderr or "Runtime error (non-zero exit code)"

        return 'AC', result.stdout.strip()

    except subprocess.TimeoutExpired:
        return 'TLE', ''
    except Exception as e:
        return 'RE', str(e)


def prepare_source_file(code: str, temp_dir: str) -> str:
    """
    Prepare Java source file with correct filename based on class name

    Args:
        code: Source code
        temp_dir: Temporary directory

    Returns:
        str: Path to prepared source file
    """
    # Extract class name from code
    class_name = extract_class_name(code)
    if class_name:
        filename = f'{class_name}.java'
    else:
        filename = 'Main.java'

    source_file = os.path.join(temp_dir, filename)

    try:
        with open(source_file, 'w', encoding='utf-8') as f:
            f.write(code)
        return source_file
    except Exception as e:
        raise RuntimeError(f"Failed to write Java source file: {e}")


def get_template_code() -> str:
    """Get template code for Java"""
    return '''import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Your Java solution here

        sc.close();
    }
}'''