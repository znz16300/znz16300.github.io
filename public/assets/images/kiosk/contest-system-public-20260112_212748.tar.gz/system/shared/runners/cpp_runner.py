#!/usr/bin/env python3
"""
C++ language runner for competitive programming judge
"""

import os
import subprocess
import time
from typing import Tuple


def get_language_info():
    """Get C++ language configuration"""
    return {
        'name': 'C++',
        'source_ext': '.cpp',
        'executable_ext': '',
        'time_multiplier': 1.0,
        'compile_timeout': 10,
        'needs_compilation': True
    }


def compile_code(source_file: str, temp_dir: str) -> Tuple[bool, str]:
    """
    Compile C++ code

    Returns:
        Tuple[bool, str]: (success, error_message)
    """
    executable_file = os.path.join(temp_dir, 'solution')

    try:
        compile_result = subprocess.run([
            'g++', '-o', executable_file, source_file, '-std=c++17', '-O2'
        ],
        capture_output=True,
        timeout=10,
        text=True,
        cwd=temp_dir
        )

        if compile_result.returncode != 0:
            return False, compile_result.stderr

        return True, ""

    except subprocess.TimeoutExpired:
        return False, "Compilation timed out after 10 seconds"
    except FileNotFoundError:
        return False, "C++ compiler (g++) not found. Please install GCC."
    except Exception as e:
        return False, str(e)


def run_code(source_file: str, input_data: str, time_limit: float, temp_dir: str) -> Tuple[str, str]:
    """
    Execute C++ code with given input

    Args:
        source_file: Path to C++ source file
        input_data: Input data as string
        time_limit: Time limit in seconds
        temp_dir: Temporary directory path

    Returns:
        Tuple[str, str]: (verdict, output/error_message)
        Verdicts: 'AC' (Accepted), 'TLE' (Time Limit Exceeded), 'RE' (Runtime Error)
    """
    executable_file = os.path.join(temp_dir, 'solution')

    try:
        result = subprocess.run([
            executable_file
        ],
        input=input_data,
        capture_output=True,
        timeout=time_limit,
        text=True,
        cwd=temp_dir
        )

        if result.returncode != 0:
            return 'RE', result.stderr or "Runtime error (non-zero exit code)"

        return 'AC', result.stdout.strip()

    except subprocess.TimeoutExpired:
        return 'TLE', ''
    except Exception as e:
        return 'RE', str(e)


def warmup_executable(source_file: str, temp_dir: str) -> bool:
    """
    Warm up the executable by running it once with empty input.
    This helps eliminate first-run overhead like OS caching, process setup, etc.

    Args:
        source_file: Path to source file (not used for C++, but kept for consistency)
        temp_dir: Temporary directory path

    Returns:
        bool: True if warmup successful, False otherwise
    """
    executable_file = os.path.join(temp_dir, 'solution')

    try:
        # Quick warmup run with minimal input and tight timeout
        # This doesn't need to succeed, just needs to load the binary
        subprocess.run([
            executable_file
        ],
        input="",
        capture_output=True,
        timeout=1.0,  # Very short timeout for warmup
        text=True,
        cwd=temp_dir
        )
        return True
    except:
        # Warmup failure is not critical, just return False
        return False


def prepare_source_file(code: str, temp_dir: str) -> str:
    """
    Prepare C++ source file

    Args:
        code: Source code
        temp_dir: Temporary directory

    Returns:
        str: Path to prepared source file
    """
    source_file = os.path.join(temp_dir, 'solution.cpp')

    try:
        with open(source_file, 'w', encoding='utf-8') as f:
            f.write(code)
        return source_file
    except Exception as e:
        raise RuntimeError(f"Failed to write C++ source file: {e}")


def get_template_code() -> str:
    """Get template code for C++"""
    return '''#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    // Your C++ solution here

    return 0;
}'''