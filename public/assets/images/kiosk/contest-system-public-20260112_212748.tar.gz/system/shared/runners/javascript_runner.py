#!/usr/bin/env python3
"""
JavaScript language runner for competitive programming judge
"""

import os
import subprocess
import time
from typing import Tuple


def get_language_info():
    """Get JavaScript language configuration"""
    return {
        'name': 'JavaScript',
        'source_ext': '.js',
        'executable_ext': None,
        'time_multiplier': 2.0,
        'compile_timeout': 0,
        'needs_compilation': False
    }


def compile_code(source_file: str, temp_dir: str) -> Tuple[bool, str]:
    """
    Compile JavaScript code (no compilation needed for JavaScript)

    Returns:
        Tuple[bool, str]: (success, error_message)
    """
    # JavaScript doesn't need compilation
    return True, ""


def run_code(source_file: str, input_data: str, time_limit: float, temp_dir: str) -> Tuple[str, str]:
    """
    Execute JavaScript code with given input

    Args:
        source_file: Path to JavaScript source file
        input_data: Input data as string
        time_limit: Time limit in seconds (will be multiplied by 2.0)
        temp_dir: Temporary directory path

    Returns:
        Tuple[str, str]: (verdict, output/error_message)
        Verdicts: 'AC' (Accepted), 'TLE' (Time Limit Exceeded), 'RE' (Runtime Error)
    """
    adjusted_time_limit = time_limit * 2.0  # JavaScript time multiplier

    try:
        start_time = time.time()

        result = subprocess.run([
            'node', source_file
        ],
        input=input_data,
        capture_output=True,
        timeout=adjusted_time_limit,
        text=True,
        cwd=temp_dir
        )

        execution_time = time.time() - start_time

        if result.returncode != 0:
            return 'RE', result.stderr or "Runtime error (non-zero exit code)"

        return 'AC', result.stdout.strip()

    except subprocess.TimeoutExpired:
        return 'TLE', ''
    except FileNotFoundError:
        return 'RE', "Node.js not found. Please install Node.js."
    except Exception as e:
        return 'RE', str(e)


def prepare_source_file(code: str, temp_dir: str) -> str:
    """
    Prepare JavaScript source file

    Args:
        code: Source code
        temp_dir: Temporary directory

    Returns:
        str: Path to prepared source file
    """
    source_file = os.path.join(temp_dir, 'solution.js')

    try:
        with open(source_file, 'w', encoding='utf-8') as f:
            f.write(code)
        return source_file
    except Exception as e:
        raise RuntimeError(f"Failed to write JavaScript source file: {e}")


def get_template_code() -> str:
    """Get template code for JavaScript"""
    return '''const fs = require('fs');

// Read all input at once
const input = fs.readFileSync('/dev/stdin', 'utf8').trim().split('\\n');

// Your JavaScript solution here

// Example:
// const n = parseInt(input[0]);
// const arr = input[1].split(' ').map(Number);

// console.log("result");'''