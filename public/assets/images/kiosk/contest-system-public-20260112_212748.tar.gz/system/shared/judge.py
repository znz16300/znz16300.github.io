#!/usr/bin/env python3
"""
Competitive Programming Judge Engine - Contest-Based Version
Multi-language solution testing system with contest folder structure
"""

import json
import os
import sys
import time
import shutil
import importlib
import re
from typing import Dict, List, Tuple, Optional, Any


def get_verdict_translation(verdict):
    """Повертає український переклад вердикту"""
    verdict_names = {
        'AC': 'Зараховано',
        'WA': 'Неправильна відповідь',
        'TLE': 'Перевищено час',
        'RE': 'Помилка виконання',
        'CE': 'Помилка компіляції',
        'ERROR': 'Системна помилка'
    }
    return verdict_names.get(verdict, verdict)


def normalize_output(text: str) -> str:
    """
    Normalize output for flexible comparison

    This function makes the judge more lenient with whitespace by:
    - Removing leading/trailing whitespace from each line
    - Removing empty lines
    - Collapsing multiple consecutive spaces into single spaces
    - Handling different line ending formats

    Args:
        text: Raw output text

    Returns:
        str: Normalized text for comparison
    """
    if not text:
        return ""

    # Split into lines and normalize each line
    lines = []
    for line in text.splitlines():
        # Strip leading/trailing whitespace from each line
        line = line.strip()

        # Skip empty lines
        if not line:
            continue

        # Collapse multiple spaces into single spaces
        line = re.sub(r'\s+', ' ', line)

        lines.append(line)

    # Join lines with single newlines
    return '\n'.join(lines)


def outputs_match(expected: str, actual: str) -> bool:
    """
    Compare two outputs with flexible whitespace handling

    Args:
        expected: Expected output
        actual: Actual program output

    Returns:
        bool: True if outputs are equivalent (ignoring whitespace differences)
    """
    return normalize_output(expected) == normalize_output(actual)


class BlockResult:
    """Container for block-based judging results"""

    def __init__(self, block_id: str, name: str, max_score: int):
        self.block_id = block_id
        self.name = name
        self.max_score = max_score
        self.test_results = []
        self.score = 0
        self.passed_tests = 0
        self.total_tests = 0
        self.verdict = None

    def add_test_result(self, test_id: str, score: int, verdict: str, exec_time: float,
                       input_data: str = "", expected: str = "", actual: str = ""):
        """Add a test result to this block"""
        self.test_results.append({
            'test_id': test_id,
            'score': score,
            'earned_score': score if verdict == 'AC' else 0,
            'verdict': verdict,
            'time': exec_time,
            'input': input_data,
            'expected': expected,
            'actual': actual
        })

        if verdict == 'AC':
            self.score += score
            self.passed_tests += 1
        self.total_tests += 1

    def get_verdict(self) -> str:
        """Get overall verdict for this block"""
        if not self.test_results:
            return 'NO_TESTS'

        if self.passed_tests == self.total_tests:
            return 'AC'

        verdicts = [test['verdict'] for test in self.test_results]
        if 'TLE' in verdicts:
            return 'TLE'
        if 'RE' in verdicts:
            return 'RE'
        return 'WA'

    def to_dict(self) -> dict:
        """Convert block result to dictionary"""
        return {
            'block_id': self.block_id,
            'name': self.name,
            'max_score': self.max_score,
            'score': self.score,
            'passed_tests': self.passed_tests,
            'total_tests': self.total_tests,
            'verdict': self.get_verdict(),
            'test_results': self.test_results
        }


class BlockJudgeResult:
    """Enhanced judge result with block-based scoring"""

    def __init__(self):
        self.verdict = None
        self.compile_error = None
        self.total_score = 0
        self.max_total_score = 0
        self.blocks = []
        self.overall_passed_tests = 0
        self.overall_total_tests = 0
        self.total_time = 0.0

    def add_block_result(self, block_result: BlockResult):
        """Add a block result"""
        self.blocks.append(block_result)
        self.total_score += block_result.score
        self.max_total_score += block_result.max_score
        self.overall_passed_tests += block_result.passed_tests
        self.overall_total_tests += block_result.total_tests
        self.total_time += sum(test['time'] for test in block_result.test_results)

    def get_overall_verdict(self) -> str:
        """Determine overall verdict"""
        if self.compile_error:
            return 'CE'

        if not self.blocks:
            return 'NO_TESTS'

        if self.overall_passed_tests == self.overall_total_tests:
            return 'AC'

        # Get all verdicts from all blocks
        all_verdicts = []
        for block in self.blocks:
            all_verdicts.extend([test['verdict'] for test in block.test_results])

        if 'TLE' in all_verdicts:
            return 'TLE'
        if 'RE' in all_verdicts:
            return 'RE'
        return 'WA'

    def to_dict(self) -> dict:
        """Convert to dictionary with full block details"""
        return {
            'verdict': self.verdict or self.get_overall_verdict(),
            'total_score': self.total_score,
            'max_total_score': self.max_total_score,
            'passed_tests': self.overall_passed_tests,
            'total_tests': self.overall_total_tests,
            'total_time': self.total_time,
            'compile_error': self.compile_error,
            'blocks': [block.to_dict() for block in self.blocks]
        }

    def to_dict_clean(self) -> dict:
        """Convert to dictionary without test details"""
        return {
            'verdict': self.verdict or self.get_overall_verdict(),
            'total_score': self.total_score,
            'max_total_score': self.max_total_score,
            'passed_tests': self.overall_passed_tests,
            'total_tests': self.overall_total_tests,
            'total_time': self.total_time,
            'compile_error': self.compile_error,
            'block_summary': [
                {
                    'block_id': block.block_id,
                    'name': block.name,
                    'score': block.score,
                    'max_score': block.max_score,
                    'verdict': block.get_verdict()
                } for block in self.blocks
            ]
        }


class JudgeResult:
    """Container for judging results with detailed test case information"""

    def __init__(self):
        self.verdict = None  # Overall verdict: AC, WA, TLE, RE, CE
        self.test_results = []  # List of individual test results
        self.total_time = 0.0
        self.compile_error = None
        self.passed_tests = 0
        self.total_tests = 0

    def add_test_result(self, test_num: int, verdict: str, exec_time: float,
                       input_data: str, expected: str, actual: str = ""):
        """Add a test case result"""
        self.test_results.append({
            'test': test_num,
            'verdict': verdict,
            'time': exec_time,
            'input': input_data,
            'expected': expected,
            'actual': actual
        })

        if verdict == 'AC':
            self.passed_tests += 1
        self.total_tests += 1
        self.total_time += exec_time

    def get_overall_verdict(self) -> str:
        """Determine overall verdict based on individual test results"""
        if self.compile_error:
            return 'CE'

        if not self.test_results:
            return 'NO_TESTS'

        # Check if all tests passed
        if self.passed_tests == self.total_tests:
            return 'AC'

        # Check for specific failure types
        verdicts = [test['verdict'] for test in self.test_results]
        if 'TLE' in verdicts:
            return 'TLE'
        if 'RE' in verdicts:
            return 'RE'

        return 'WA'

    def to_dict(self) -> dict:
        """Convert result to dictionary for JSON serialization"""
        return {
            'verdict': self.verdict or self.get_overall_verdict(),
            'passed_tests': self.passed_tests,
            'total_tests': self.total_tests,
            'total_time': self.total_time,
            'compile_error': self.compile_error,
            'test_results': self.test_results
        }

    def to_dict_clean(self) -> dict:
        """Convert result to dictionary for storage without any test case details"""
        return {
            'verdict': self.verdict or self.get_overall_verdict(),
            'passed_tests': self.passed_tests,
            'total_tests': self.total_tests,
            'total_time': self.total_time,
            'compile_error': self.compile_error
        }


class LanguageRunner:
    """Language runner interface and factory"""

    @classmethod
    def get_runner(cls, language: str, system_config: Dict[str, Any]):
        """Get language runner module using system configuration"""
        if language not in system_config.get('languages', {}):
            available = list(system_config.get('languages', {}).keys())
            raise ValueError(f"Language '{language}' not supported. Available: {available}")

        lang_config = system_config['languages'][language]
        if not lang_config.get('enabled', True):
            raise ValueError(f"Language '{language}' is disabled")

        # Add runners directory to Python path
        current_dir = os.path.dirname(os.path.abspath(__file__))
        runners_dir = os.path.join(current_dir, 'runners')
        if runners_dir not in sys.path:
            sys.path.insert(0, runners_dir)

        module_name = lang_config['runner_module']
        try:
            # Force reload to get latest changes (especially for Pascal fixes)
            if module_name in sys.modules:
                importlib.reload(sys.modules[module_name])
            runner_module = importlib.import_module(module_name)
            return runner_module
        except ImportError as e:
            raise ImportError(f"Failed to load runner for {language}: {e}")


def load_system_config() -> Dict[str, Any]:
    """Load system configuration from system/config.json"""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    config_file = os.path.join(current_dir, 'config.json')

    try:
        with open(config_file, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        raise FileNotFoundError(f"System configuration file not found: {config_file}")
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in system config: {e}")


def load_contest_config(contest_dir: str = 'contest') -> Dict[str, Any]:
    """Load contest configuration from contest.json"""
    config_file = os.path.join(contest_dir, 'contest.json')

    try:
        with open(config_file, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        raise FileNotFoundError(f"Contest configuration file not found: {config_file}")
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in contest config: {e}")


def load_problem_metadata(problem_id: str, contest_dir: str = 'contest') -> Dict[str, Any]:
    """Load problem metadata from contest/{problem_id}/problem.json"""
    problem_file = os.path.join(contest_dir, problem_id, 'problem.json')

    try:
        with open(problem_file, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        raise FileNotFoundError(f"Problem file not found: {problem_file}")
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in problem file: {e}")


def load_test_cases(problem_id: str, contest_dir: str = 'contest') -> List[Tuple[str, str, str]]:
    """Load all public test cases for a problem using the testing.json file"""
    test_cases = []

    # Load public test configuration
    public_config = load_public_test_config(problem_id, contest_dir)

    if not public_config:
        raise FileNotFoundError(f"Public test config (testing.json) not found for problem {problem_id}")

    # Get test cases directory
    tests_dir = os.path.join(contest_dir, problem_id, 'tests', 'tests')

    if not os.path.exists(tests_dir):
        raise FileNotFoundError(f"Public test directory not found: {tests_dir}")

    # Load test cases based on config
    for block_config in public_config['blocks']:
        block_id = block_config['block_id']

        for test_config in block_config['tests']:
            test_id = test_config['test_id']

            # Build file paths
            input_file = os.path.join(tests_dir, f"{block_id}-{test_id}.in")
            output_file = os.path.join(tests_dir, f"{block_id}-{test_id}.out")

            if not os.path.exists(input_file) or not os.path.exists(output_file):
                print(f"Warning: Missing test files for {block_id}-{test_id}")
                continue

            try:
                # Read input file
                with open(input_file, 'r', encoding='utf-8') as f:
                    input_data = f.read().strip()

                # Read output file
                with open(output_file, 'r', encoding='utf-8') as f:
                    expected_output = f.read().strip()

                # Generate test name
                if block_id == 0:
                    test_name = f"Example {test_id}"
                else:
                    test_name = f"Test {block_id}-{test_id}"

                test_cases.append((test_name, input_data, expected_output))

            except Exception as e:
                print(f"Warning: Failed to load test case {block_id}-{test_id}: {e}")
                continue

    if not test_cases:
        raise ValueError(f"No valid test cases found for problem {problem_id}")

    return test_cases


def get_problem_config(problem_id: str, contest_config: Dict[str, Any]) -> Dict[str, Any]:
    """Get problem-specific configuration from problem.json file"""
    # Load problem metadata which now contains the configuration
    problem_config = load_problem_metadata(problem_id)
    return {
        'id': problem_id,
        'name': problem_config['name'],
        'time_limit': problem_config['time_limit'],
        'memory_limit': problem_config['memory_limit'],
        'points': problem_config['points']
    }


def judge_solution(problem_id: str, language: str, code: str,
                  contest_dir: str = 'contest',
                  temp_dir: str = 'temp') -> JudgeResult:
    """Main judging function - test solution against all test cases using contest structure"""

    result = JudgeResult()

    try:
        # Resolve paths to absolute paths
        contest_dir = os.path.abspath(contest_dir) if not os.path.isabs(contest_dir) else contest_dir
        temp_dir = os.path.abspath(temp_dir) if not os.path.isabs(temp_dir) else temp_dir

        # Ensure temp directory exists
        os.makedirs(temp_dir, exist_ok=True)

        # Load system and contest configurations
        system_config = load_system_config()
        contest_config = load_contest_config(contest_dir)

        # Get language runner
        runner = LanguageRunner.get_runner(language, system_config)
        lang_info = runner.get_language_info()

        # Get problem configuration
        problem_config = get_problem_config(problem_id, contest_config)
        time_limit = problem_config.get('time_limit', 2.0)

        # Load test cases
        test_cases = load_test_cases(problem_id, contest_dir)


        # Prepare source file
        try:
            source_file = runner.prepare_source_file(code, temp_dir)
        except Exception as e:
            result.compile_error = str(e)
            result.verdict = 'CE'
            return result

        # Compile if needed
        if lang_info['needs_compilation']:
            try:
                compile_success, compile_error = runner.compile_code(source_file, temp_dir)
                if not compile_success:
                    result.compile_error = compile_error
                    result.verdict = 'CE'
                    return result

                # Warm up executable for compiled languages (eliminates first-run overhead)
                if hasattr(runner, 'warmup_executable'):
                    try:
                        runner.warmup_executable(source_file, temp_dir)
                    except:
                        pass  # Warmup failure is not critical

            except Exception as e:
                result.compile_error = str(e)
                result.verdict = 'CE'
                return result

        # Test against each test case
        for test_name, input_data, expected_output in test_cases:
            start_time = time.time()

            try:
                verdict, actual_output = runner.run_code(source_file, input_data, time_limit, temp_dir)
                execution_time = time.time() - start_time

                # Check output for AC cases
                if verdict == 'AC':
                    if outputs_match(expected_output, actual_output):
                        verdict = 'AC'
                    else:
                        verdict = 'WA'

                result.add_test_result(
                    len(result.test_results) + 1,
                    verdict,
                    execution_time,
                    input_data,
                    expected_output,
                    actual_output if verdict in ['WA', 'AC'] else ""
                )

            except Exception as e:
                execution_time = time.time() - start_time
                result.add_test_result(
                    len(result.test_results) + 1,
                    'RE',
                    execution_time,
                    input_data,
                    expected_output,
                    str(e)
                )

        # Set overall verdict
        result.verdict = result.get_overall_verdict()

    except Exception as e:
        result.compile_error = str(e)
        result.verdict = 'CE'

    return result


def display_results(result: JudgeResult) -> None:
    """Display judging results in a formatted way"""

    print("\n" + "=" * 60)
    print("JUDGING RESULTS")
    print("=" * 60)

    if result.verdict == 'CE':
        print("❌ COMPILATION ERROR")
        print(f"Error: {result.compile_error}")
        return

    if not result.test_results:
        print("⚠️  NO TESTS RUN")
        return

    # Overall summary
    verdict_emoji = {
        'AC': '✅',
        'WA': '❌',
        'TLE': '⏰',
        'RE': '💥'
    }

    print(f"{verdict_emoji.get(result.verdict, '❓')} Overall Verdict: {get_verdict_translation(result.verdict)}")
    print(f"📊 Tests Passed: {result.passed_tests}/{result.total_tests}")
    print(f"⏱️  Total Time: {result.total_time:.3f}s")
    print()

    # Individual test results
    for test in result.test_results:
        status = "✅" if test['verdict'] == 'AC' else "❌"
        print(f"{status} Test {test['test']:2d}: {get_verdict_translation(test['verdict'])} ({test['time']:.3f}s)")

        # Show details for failed tests
        if test['verdict'] in ['WA', 'TLE', 'RE']:
            print(f"     Input: {test['input'][:100]}{'...' if len(test['input']) > 100 else ''}")

            if test['verdict'] == 'WA':
                print(f"  Expected: {test['expected'][:100]}{'...' if len(test['expected']) > 100 else ''}")
                print(f"    Actual: {test['actual'][:100]}{'...' if len(test['actual']) > 100 else ''}")
            elif test['verdict'] == 'TLE':
                print(f"     Error: Time limit exceeded")
            elif test['verdict'] == 'RE':
                print(f"     Error: Runtime error")

            print()

    print("=" * 60)


def format_results(result: JudgeResult) -> str:
    """Format results as a string for programmatic use"""
    if result.verdict == 'CE':
        return f"CE: {result.compile_error}"

    summary = f"{get_verdict_translation(result.verdict)}: {result.passed_tests}/{result.total_tests} tests passed ({result.total_time:.3f}s)"

    if result.verdict != 'AC':
        failed_tests = [test for test in result.test_results if test['verdict'] != 'AC']
        if failed_tests:
            summary += f"\nFirst failure: Test {failed_tests[0]['test']} ({failed_tests[0]['verdict']})"

    return summary


# Cleanup function
def cleanup_temp_files(temp_dir: str = 'temp') -> None:
    """Clean up temporary files"""
    if os.path.exists(temp_dir):
        try:
            shutil.rmtree(temp_dir)
            os.makedirs(temp_dir, exist_ok=True)
        except Exception as e:
            print(f"Warning: Failed to cleanup temp directory: {e}")


# Contest information functions
def get_contest_info(contest_dir: str = 'contest') -> Dict[str, Any]:
    """Get contest information"""
    try:
        contest_config = load_contest_config(contest_dir)
        return {
            'name': contest_config.get('contest_name', 'Змагання з програмування'),
            'submission_form': contest_config.get('submission_form')
        }
    except Exception:
        return {'name': 'Змагання з програмування', 'submission_form': None}


def get_available_problems(contest_dir: str = 'contest') -> List[Dict[str, Any]]:
    """Get list of available problems with complete metadata"""
    try:
        contest_config = load_contest_config(contest_dir)
        problems = []

        for problem in contest_config.get('problems', []):
            problem_id = problem['id']
            try:
                # Load complete problem metadata from individual problem.json
                problem_metadata = load_problem_metadata(problem_id, contest_dir)
                problems.append({
                    'id': problem_id,
                    'name': problem_metadata.get('name', f'Problem {problem_id}'),
                    'title': problem_metadata.get('title', f'Problem {problem_id}'),
                    'time_limit': problem_metadata.get('time_limit', 2.0),
                    'memory_limit': problem_metadata.get('memory_limit', 256),
                    'points': problem_metadata.get('points', 100)
                })
            except Exception as e:
                # If problem.json can't be loaded, skip this problem
                print(f"Warning: Could not load metadata for problem {problem_id}: {e}")
                continue

        return problems
    except Exception:
        return []


def get_available_languages() -> List[str]:
    """Get list of available languages"""
    try:
        system_config = load_system_config()
        languages = system_config.get('languages', {})
        return [lang for lang, config in languages.items() if config.get('enabled', True)]
    except Exception:
        return []


def get_default_language() -> str:
    """Get the first enabled language as default"""
    try:
        languages = get_available_languages()
        return languages[0] if languages else 'Python'
    except Exception:
        return 'Python'


def get_language_extensions() -> Dict[str, str]:
    """Get mapping of language names to file extensions from config"""
    try:
        system_config = load_system_config()
        languages = system_config.get('languages', {})
        return {
            lang: config.get('file_extension', '.txt')
            for lang, config in languages.items()
            if config.get('enabled', True)
        }
    except Exception:
        return {}


def get_language_display_names() -> Dict[str, str]:
    """Get mapping of language names to display names from config"""
    try:
        system_config = load_system_config()
        languages = system_config.get('languages', {})
        return {
            lang: config.get('display_name', lang)
            for lang, config in languages.items()
            if config.get('enabled', True)
        }
    except Exception:
        return {}


def get_template_code(language: str) -> str:
    """Get template code for a language"""
    try:
        system_config = load_system_config()
        runner = LanguageRunner.get_runner(language, system_config)
        return runner.get_template_code()
    except Exception:
        return f"// Your {language} solution here\n"


# Main testing function for direct usage
def load_private_test_config(problem_id: str, contest_dir: str = 'contest') -> Optional[Dict]:
    """Load private test configuration for block-based testing"""
    config_path = os.path.join(contest_dir, problem_id, 'private-tests', 'testing.json')

    if not os.path.exists(config_path):
        return None

    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Warning: Could not load private test config for {problem_id}: {e}")
        return None


def load_public_test_config(problem_id: str, contest_dir: str = 'contest') -> Optional[Dict]:
    """Load public test configuration"""
    config_path = os.path.join(contest_dir, problem_id, 'tests', 'testing.json')

    if not os.path.exists(config_path):
        return None

    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Warning: Could not load public test config for {problem_id}: {e}")
        return None


def load_private_test_cases(problem_id: str, block_id: int, contest_dir: str = 'contest') -> Dict[int, Tuple[str, str]]:
    """Load private test cases for a specific block from the tests/ folder"""
    tests_dir = os.path.join(contest_dir, problem_id, 'private-tests', 'tests')
    test_cases = {}

    if not os.path.exists(tests_dir):
        return test_cases

    # Find all test files for this block
    test_files = []
    for filename in os.listdir(tests_dir):
        if filename.startswith(f"{block_id}-") and filename.endswith('.in'):
            test_files.append(filename)

    test_files.sort()

    for filename in test_files:
        # Extract test_id from filename (e.g., "1-2.in" -> test_id = 2)
        try:
            parts = filename.replace('.in', '').split('-')
            if len(parts) == 2 and int(parts[0]) == block_id:
                test_id = int(parts[1])

                input_file = os.path.join(tests_dir, filename)
                output_file = os.path.join(tests_dir, f"{block_id}-{test_id}.out")

                if os.path.exists(output_file):
                    with open(input_file, 'r', encoding='utf-8') as f:
                        input_data = f.read().strip()
                    with open(output_file, 'r', encoding='utf-8') as f:
                        expected_output = f.read().strip()

                    test_cases[test_id] = (input_data, expected_output)
        except (ValueError, FileNotFoundError) as e:
            print(f"Warning: Could not load test case {filename}: {e}")
            continue

    return test_cases


def judge_solution_with_blocks(problem_id: str, language: str, code: str,
                              contest_dir: str = 'contest',
                              temp_dir: str = 'temp') -> BlockJudgeResult:
    """Judge solution using block-based testing with private test configurations"""

    result = BlockJudgeResult()

    try:
        # Load private test configuration
        private_config = load_private_test_config(problem_id, contest_dir)

        if not private_config:
            # Fall back to regular testing
            regular_result = judge_solution(problem_id, language, code, contest_dir, temp_dir)

            # Convert regular result to block result
            fallback_block = BlockResult(0, "All Tests", 100)
            for i, test in enumerate(regular_result.test_results):
                score = 100 // regular_result.total_tests if regular_result.total_tests > 0 else 0
                fallback_block.add_test_result(
                    i+1,
                    score,
                    test['verdict'],
                    test['time'],
                    test['input'],
                    test['expected'],
                    test['actual']
                )

            result.add_block_result(fallback_block)
            if regular_result.compile_error:
                result.compile_error = regular_result.compile_error
                result.verdict = 'CE'

            return result

        # Resolve paths
        contest_dir = os.path.abspath(contest_dir) if not os.path.isabs(contest_dir) else contest_dir
        temp_dir = os.path.abspath(temp_dir) if not os.path.isabs(temp_dir) else temp_dir
        os.makedirs(temp_dir, exist_ok=True)

        # Load system configuration
        system_config = load_system_config()
        contest_config = load_contest_config(contest_dir)

        # Get language runner
        runner = LanguageRunner.get_runner(language, system_config)
        lang_info = runner.get_language_info()

        # Get problem configuration
        problem_config = get_problem_config(problem_id, contest_config)
        time_limit = problem_config.get('time_limit', 2.0)


        # Prepare source file
        try:
            source_file = runner.prepare_source_file(code, temp_dir)
        except Exception as e:
            result.compile_error = str(e)
            result.verdict = 'CE'
            return result

        # Compile if needed
        if lang_info['needs_compilation']:
            try:
                compile_success, compile_error = runner.compile_code(source_file, temp_dir)
                if not compile_success:
                    result.compile_error = compile_error
                    result.verdict = 'CE'
                    return result

                # Warm up executable for compiled languages (eliminates first-run overhead)
                if hasattr(runner, 'warmup_executable'):
                    try:
                        runner.warmup_executable(source_file, temp_dir)
                    except:
                        pass  # Warmup failure is not critical

            except Exception as e:
                result.compile_error = str(e)
                result.verdict = 'CE'
                return result

        # Process each block
        for block_config in private_config['blocks']:
            block_id = block_config['block_id']

            # Calculate max score for this block
            max_score = sum(test['score'] for test in block_config['tests'])

            # Generate block name
            block_name = f"Блок {block_id}" if block_id > 0 else "Приклади"

            block_result = BlockResult(block_id, block_name, max_score)


            # Load test cases for this block
            test_cases = load_private_test_cases(problem_id, block_id, contest_dir)

            # Test each test in the block
            for test_config in block_config['tests']:
                test_id = test_config['test_id']
                test_score = test_config['score']

                # Find corresponding test case
                if test_id in test_cases:
                    input_data, expected_output = test_cases[test_id]

                    start_time = time.time()
                    try:
                        verdict, actual_output = runner.run_code(
                            source_file, input_data,
                            time_limit * lang_info['time_multiplier'],
                            temp_dir
                        )
                        execution_time = time.time() - start_time

                        # Check output for AC cases
                        if verdict == 'AC':
                            if outputs_match(expected_output, actual_output):
                                verdict = 'AC'
                            else:
                                verdict = 'WA'

                        block_result.add_test_result(
                            test_id, test_score, verdict, execution_time,
                            input_data, expected_output,
                            actual_output if verdict in ['WA', 'AC'] else ""
                        )


                    except Exception as e:
                        execution_time = time.time() - start_time
                        block_result.add_test_result(test_id, test_score, 'RE', execution_time)

                else:
                    # Test case not found
                    block_result.add_test_result(test_id, test_score, 'ERROR', 0.0)

            result.add_block_result(block_result)

        return result

    except Exception as e:
        result.compile_error = str(e)
        result.verdict = 'ERROR'
        return result
    finally:
        cleanup_temp_files(temp_dir)


def judge_solution_with_public_blocks(problem_id: str, language: str, code: str,
                                     contest_dir: str = 'contest',
                                     temp_dir: str = 'temp') -> BlockJudgeResult:
    """Judge solution using public block-based testing"""

    result = BlockJudgeResult()

    try:
        # Load public test configuration
        public_config = load_public_test_config(problem_id, contest_dir)

        if not public_config:
            # Fall back to regular testing
            regular_result = judge_solution(problem_id, language, code, contest_dir, temp_dir)

            # Convert regular result to block result
            fallback_block = BlockResult(0, "All Tests", 100)
            for i, test in enumerate(regular_result.test_results):
                score = 100 // regular_result.total_tests if regular_result.total_tests > 0 else 0
                fallback_block.add_test_result(
                    i+1,
                    score,
                    test['verdict'],
                    test['time'],
                    test['input'],
                    test['expected'],
                    test['actual']
                )

            result.add_block_result(fallback_block)
            if regular_result.compile_error:
                result.compile_error = regular_result.compile_error
                result.verdict = 'CE'

            return result

        # Resolve paths
        contest_dir = os.path.abspath(contest_dir) if not os.path.isabs(contest_dir) else contest_dir
        temp_dir = os.path.abspath(temp_dir) if not os.path.isabs(temp_dir) else temp_dir
        os.makedirs(temp_dir, exist_ok=True)

        # Load system configuration
        system_config = load_system_config()
        contest_config = load_contest_config(contest_dir)

        # Get language runner
        runner = LanguageRunner.get_runner(language, system_config)
        lang_info = runner.get_language_info()

        # Get problem configuration
        problem_config = get_problem_config(problem_id, contest_config)
        time_limit = problem_config.get('time_limit', 2.0)


        # Prepare source file
        try:
            source_file = runner.prepare_source_file(code, temp_dir)
        except Exception as e:
            result.compile_error = str(e)
            result.verdict = 'CE'
            return result

        # Compile if needed
        if lang_info['needs_compilation']:
            try:
                compile_success, compile_error = runner.compile_code(source_file, temp_dir)
                if not compile_success:
                    result.compile_error = compile_error
                    result.verdict = 'CE'
                    return result

                # Warm up executable for compiled languages (eliminates first-run overhead)
                if hasattr(runner, 'warmup_executable'):
                    try:
                        runner.warmup_executable(source_file, temp_dir)
                    except:
                        pass  # Warmup failure is not critical

            except Exception as e:
                result.compile_error = str(e)
                result.verdict = 'CE'
                return result

        # Process each block from PUBLIC tests
        for block_config in public_config['blocks']:
            block_id = block_config['block_id']

            # Calculate max score for this block
            max_score = sum(test['score'] for test in block_config['tests'])

            # Generate block name
            block_name = f"Блок {block_id}" if block_id > 0 else "Приклади"

            block_result = BlockResult(block_id, block_name, max_score)


            # Load test cases for this block from PUBLIC tests folder
            test_cases = load_public_test_cases(problem_id, block_id, contest_dir)

            # Test each test in the block
            for test_config in block_config['tests']:
                test_id = test_config['test_id']
                test_score = test_config['score']

                # Find corresponding test case
                if test_id in test_cases:
                    input_data, expected_output = test_cases[test_id]

                    start_time = time.time()
                    try:
                        verdict, actual_output = runner.run_code(
                            source_file, input_data,
                            time_limit * lang_info['time_multiplier'],
                            temp_dir
                        )
                        execution_time = time.time() - start_time

                        # Check output for AC cases
                        if verdict == 'AC':
                            if outputs_match(expected_output, actual_output):
                                verdict = 'AC'
                            else:
                                verdict = 'WA'

                        block_result.add_test_result(
                            test_id, test_score, verdict, execution_time,
                            input_data, expected_output,
                            actual_output if verdict in ['WA', 'AC'] else ""
                        )


                    except Exception as e:
                        execution_time = time.time() - start_time
                        block_result.add_test_result(test_id, test_score, 'RE', execution_time)

                else:
                    # Test case not found
                    block_result.add_test_result(test_id, test_score, 'ERROR', 0.0)

            result.add_block_result(block_result)

        return result

    except Exception as e:
        result.compile_error = str(e)
        result.verdict = 'ERROR'
        return result
    finally:
        cleanup_temp_files(temp_dir)


def load_public_test_cases(problem_id: str, block_id: int, contest_dir: str = 'contest') -> Dict[int, Tuple[str, str]]:
    """Load public test cases for a specific block from the tests/tests/ folder"""
    tests_dir = os.path.join(contest_dir, problem_id, 'tests', 'tests')
    test_cases = {}

    if not os.path.exists(tests_dir):
        return test_cases

    # Find all test files for this block
    test_files = []
    for filename in os.listdir(tests_dir):
        if filename.startswith(f"{block_id}-") and filename.endswith('.in'):
            test_files.append(filename)

    test_files.sort()

    for filename in test_files:
        # Extract test_id from filename (e.g., "1-2.in" -> test_id = 2)
        try:
            parts = filename.replace('.in', '').split('-')
            if len(parts) == 2 and int(parts[0]) == block_id:
                test_id = int(parts[1])

                input_file = os.path.join(tests_dir, filename)
                output_file = os.path.join(tests_dir, f"{block_id}-{test_id}.out")

                if os.path.exists(output_file):
                    with open(input_file, 'r', encoding='utf-8') as f:
                        input_data = f.read().strip()
                    with open(output_file, 'r', encoding='utf-8') as f:
                        expected_output = f.read().strip()

                    test_cases[test_id] = (input_data, expected_output)
        except (ValueError, FileNotFoundError) as e:
            print(f"Warning: Could not load public test case {filename}: {e}")
            continue

    return test_cases


def test_solution_with_public_blocks(problem_id: str, language: str, code: str, contest_dir: str = 'contest') -> dict:
    """Convenience function for public block-based testing (for participants)"""
    try:
        result = judge_solution_with_public_blocks(problem_id, language, code, contest_dir, 'temp')
        return result.to_dict()
    except Exception as e:
        return {
            'verdict': 'ERROR',
            'total_score': 0,
            'max_total_score': 0,
            'passed_tests': 0,
            'total_tests': 0,
            'total_time': 0.0,
            'compile_error': str(e),
            'blocks': []
        }


def test_solution_with_blocks(problem_id: str, language: str, code: str, contest_dir: str = 'contest') -> dict:
    """Convenience function for private block-based testing (for judges only)"""
    try:
        result = judge_solution_with_blocks(problem_id, language, code, contest_dir, 'temp')
        return result.to_dict()
    except Exception as e:
        return {
            'verdict': 'ERROR',
            'total_score': 0,
            'max_total_score': 0,
            'passed_tests': 0,
            'total_tests': 0,
            'total_time': 0.0,
            'compile_error': str(e),
            'blocks': []
        }


def test_solution(problem_id: str, language: str, code: str, contest_dir: str = 'contest') -> dict:
    """Convenience function to test a solution and return JSON results"""
    try:
        result = judge_solution(problem_id, language, code, contest_dir, 'temp')
        return result.to_dict()
    except Exception as e:
        return {
            'verdict': 'ERROR',
            'passed_tests': 0,
            'total_tests': 0,
            'total_time': 0.0,
            'compile_error': str(e),
            'test_results': []
        }
    finally:
        cleanup_temp_files('temp')


if __name__ == "__main__":
    # Example usage
    print("Competitive Programming Judge Engine - Contest-Based Version")
    print("Available languages:", ', '.join(get_available_languages()))
    print("Available problems:", [p['id'] for p in get_available_problems()])
    print("Usage: import judge; judge.test_solution('A', 'Python', 'your_code_here')")